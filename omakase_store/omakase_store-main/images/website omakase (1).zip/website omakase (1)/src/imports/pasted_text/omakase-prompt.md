# Bộ Prompt Figma – Website Omakase Online
Phong cách: Nhật Bản tối giản, sang trọng — tone đen / gỗ trầm / đỏ trầm, nền kem ngà, nhiều khoảng trắng.

**Bảng màu dùng chung:**
- Nền: `#F7F3EC` (kem ngà)
- Chữ chính: `#1A1A1A` (đen than)
- Gỗ trầm: `#4A3324`
- Đỏ trầm / vermillion: `#8C2F2F`
- Line mảnh: `#D8CFC0`
- Font: serif tinh tế cho heading (Noto Serif JP / Shippori Mincho), sans-serif mảnh cho body (Inter / Noto Sans)

> Cách dùng: copy nguyên đoạn prompt của từng layout, dán vào Figma AI (First Draft) hoặc công cụ design-AI khác. Chỉ tạo giao diện tĩnh, chưa cần chạy logic.

---

## A. Layout dành cho khách hàng

### 1. Home
Thiết kế trang chủ website đặt bàn/đặt suất Omakase (nhà hàng sushi cao cấp Nhật Bản), phong cách tối giản sang trọng Nhật Bản, tone đen – gỗ trầm – đỏ trầm, nền kem ngà, nhiều khoảng trắng. Bố cục gồm: Header với logo dạng chữ Kanji/thư pháp tối giản + menu ngang (Trang chủ, Thực đơn, Đặt chỗ, Về chúng tôi, Liên hệ) + icon giỏ hàng/tài khoản; Banner/Hero toàn màn hình với ảnh đầu bếp chế biến sushi và câu slogan lớn kiểu chữ thư pháp; thanh tìm kiếm nhỏ bên dưới hero (tìm món/chi nhánh); danh mục thực đơn dạng thẻ tròn (Omakase cơ bản, Omakase cao cấp, Set trưa, Đồ uống); phần sản phẩm/set nổi bật dạng lưới 3-4 cột với ảnh món, tên, giá; đoạn giới thiệu ngắn về triết lý ẩm thực Omakase kèm ảnh đầu bếp; khu vực khuyến mãi/thông báo (đặt sớm giảm giá) dạng banner nhỏ; Footer tối màu (đen/gỗ trầm) gồm thông tin liên hệ, giờ mở cửa, mạng xã hội, bản đồ mini.

### 2. Login
Thiết kế trang đăng nhập cho website Omakase Online, phong cách Nhật tối giản sang trọng, form đăng nhập căn giữa trên nền kem có texture giấy washi nhẹ, một bên là ảnh không gian nhà hàng/quầy sushi. Form gồm: tiêu đề "Đăng nhập", ô nhập Email/Username, ô nhập Password (có icon ẩn/hiện), checkbox "Ghi nhớ đăng nhập", link "Quên mật khẩu?", nút "Đăng nhập" màu đỏ trầm nổi bật, dòng chữ nhỏ dẫn sang trang Đăng ký. Thêm logo nhỏ phía trên form.

### 3. Register
Thiết kế trang đăng ký tài khoản, cùng phong cách Nhật tối giản sang trọng với trang Login (đồng bộ layout 2 cột: ảnh nhà hàng bên trái, form bên phải). Form gồm: tiêu đề "Tạo tài khoản", các ô nhập Họ tên, Email, Số điện thoại, Password, Confirm Password, checkbox đồng ý điều khoản, nút "Đăng ký" màu đỏ trầm, link quay lại trang Đăng nhập.

### 4. Listing (Danh sách món/set Omakase)
Thiết kế trang danh sách các set Omakase và món ăn, phong cách Nhật tối giản sang trọng. Bố cục: Header giống trang chủ; thanh breadcrumb; sidebar bộ lọc bên trái (loại set: Nigiri/Sashimi/Full-course, khoảng giá, số món trong set, đầu bếp phụ trách); khu vực chính bên phải hiển thị lưới thẻ sản phẩm 3 cột, mỗi thẻ gồm ảnh set, tên set (vd "Omakase 10 món"), số món, giá, nút "Xem chi tiết"; thanh sắp xếp (giá tăng/giảm, phổ biến nhất) phía trên lưới; phân trang ở cuối.

### 5. Search
Thiết kế trang kết quả tìm kiếm cho website Omakase, phong cách Nhật tối giản sang trọng. Trên cùng là thanh tìm kiếm lớn với placeholder "Tìm set Omakase, món ăn, chi nhánh..." và nút "Tìm kiếm" đỏ trầm. Bên dưới: sidebar bộ lọc (Danh mục: Nigiri/Sashimi/Chirashi, Khoảng giá bằng thanh trượt, Chi nhánh/Location, Đánh giá sao); phần hiển thị "Tìm thấy 25 kết quả" phía trên lưới kết quả; lưới kết quả dạng thẻ giống layout Listing.

### 6. Detail (Chi tiết set/món Omakase)
Thiết kế trang chi tiết một set Omakase, phong cách Nhật tối giản sang trọng. Bố cục 2 cột: bên trái là gallery ảnh lớn (ảnh chính + dải thumbnail nhỏ các món trong set); bên phải gồm tên set, giá, đánh giá sao (rating), mô tả ngắn triết lý món ăn, danh sách các món có trong set (dạng list có icon nhỏ), bộ chọn số lượng/số suất, nút "Đặt ngay" đỏ trầm và nút phụ "Thêm vào giỏ"; bên dưới toàn trang là tab: Mô tả chi tiết, Thông tin đầu bếp, Đánh giá của khách hàng (kèm ảnh đại diện + sao + bình luận).

### 7. Booking / Cart (Giỏ hàng & đặt suất)
Thiết kế trang giỏ hàng/đặt suất Omakase, phong cách Nhật tối giản sang trọng. Phần trên là bảng danh sách set đã chọn dạng cột: Set/Món | Đơn giá | Số lượng (bộ tăng giảm) | Thành tiền | nút xóa, có đường kẻ mảnh phân cách các dòng. Vì Omakase cần đặt chỗ theo thời gian, thêm khối "Thông tin đặt chỗ": chọn Ngày (date picker), chọn Giờ (time slot dạng nút tròn), Số lượng khách. Bên dưới bảng: Tạm tính, Phí phát sinh (nếu có), Tổng tiền, hai nút "Tiếp tục xem thực đơn" và "Thanh toán" (đỏ trầm, nổi bật).

### 8. User Profile
Thiết kế trang hồ sơ cá nhân sau đăng nhập, phong cách Nhật tối giản sang trọng. Sidebar trái tối màu (đen/gỗ trầm) gồm: Avatar tròn + tên khách hàng, và menu dọc: Thông tin cá nhân, Đơn hàng, Lịch sử đặt chỗ, Món yêu thích, Đổi mật khẩu, Đăng xuất (icon mảnh, có mục đang active highlight đỏ trầm). Bên phải là khu vực nội dung chính hiển thị form "Thông tin cá nhân" (Họ tên, Email, SĐT, Địa chỉ) với nút "Lưu thay đổi".

### 9. Order / Booking History
Thiết kế trang lịch sử đơn hàng/đặt chỗ, phong cách Nhật tối giản sang trọng, dùng chung sidebar với trang User Profile. Nội dung chính gồm: khối "Thông tin đơn hàng" dạng bảng (Set/Món, Số lượng, Ngày-giờ đặt, Tổng tiền, Trạng thái dạng nhãn màu: Đang xử lý/Hoàn tất/Đã hủy); khối "Thông tin khách hàng" (Họ tên, Địa chỉ, SĐT); khối "Phương thức thanh toán" với radio button (COD, Chuyển khoản/Banking, Ví điện tử); nút "Xác nhận thanh toán" đỏ trầm ở cuối.

---

## B. Layout dành cho Admin

### 10. Dashboard
Thiết kế trang Dashboard quản trị cho hệ thống Omakase Online, phong cách Nhật tối giản nhưng chuyên nghiệp (nền sáng, accent đỏ trầm, sidebar tối màu). Sidebar trái cố định: logo, menu dọc (Dashboard, Users, Products/Menu, Orders, Categories, Reports) với icon mảnh. Nội dung chính: hàng 4 thẻ thống kê (Tổng khách hàng, Tổng đơn/đặt chỗ, Tổng món/set đang bán, Doanh thu tháng) dạng card có icon; một biểu đồ doanh thu dạng line/bar chart chiếm 2/3 chiều ngang; bảng "Đơn hàng gần đây" chiếm phần còn lại hoặc bên dưới, dạng bảng gọn với trạng thái đơn.

### 11. CRUD Management (dùng chung cho quản lý món/set, danh mục, chi nhánh...)
Thiết kế trang quản lý CRUD dùng chung cho Admin (ví dụ Quản lý Set Omakase), phong cách tối giản chuyên nghiệp, đồng bộ sidebar với Dashboard. Nội dung: tiêu đề trang + nút "Thêm mới" (đỏ trầm, góc phải); thanh tìm kiếm/bộ lọc nhanh; bảng dữ liệu gồm cột Ảnh, Tên set, Danh mục, Giá, Trạng thái (Đang bán/Ẩn), Hành động (icon Sửa/Xóa/Xem); phân trang cuối bảng; có thể có modal/form thêm-sửa hiện dạng popup với các trường tên, mô tả, giá, ảnh, danh mục.

### 12. User Management
Thiết kế trang quản lý người dùng cho Admin, đồng bộ phong cách và sidebar với Dashboard. Nội dung: tiêu đề "Quản lý người dùng" + nút "Thêm người dùng"; thanh tìm kiếm theo tên/email; bảng gồm cột Avatar, Họ tên, Email, SĐT, Vai trò (Khách hàng/Admin), Trạng thái (Hoạt động/Khóa), Ngày tham gia, Hành động (Sửa/Khóa/Xóa); bộ lọc theo vai trò và trạng thái phía trên bảng.

### 13. Order / Booking Management
Thiết kế trang quản lý đơn hàng/đặt chỗ cho Admin, đồng bộ phong cách và sidebar. Nội dung: tiêu đề trang + bộ lọc theo trạng thái (Tabs: Tất cả/Đang xử lý/Hoàn tất/Đã hủy) + bộ lọc theo ngày; bảng gồm cột Mã đơn, Khách hàng, Set/Món đã đặt, Ngày-giờ đặt, Tổng tiền, Trạng thái (nhãn màu), Hành động (Xem chi tiết/Cập nhật trạng thái); có thể thêm khối chi tiết đơn dạng slide-panel bên phải khi click vào 1 đơn.

### 14. Report / Statistics
Thiết kế trang báo cáo thống kê cho Admin, đồng bộ phong cách và sidebar. Nội dung: bộ lọc thời gian (Tuần/Tháng/Quý/Tùy chọn) ở trên cùng; hàng thẻ tổng quan (Doanh thu, Số đơn, Khách hàng mới, Set bán chạy nhất); 2 biểu đồ lớn (biểu đồ đường doanh thu theo thời gian, biểu đồ tròn/cột tỷ trọng set bán chạy theo danh mục); bảng "Top 5 set bán chạy" ở cuối trang.