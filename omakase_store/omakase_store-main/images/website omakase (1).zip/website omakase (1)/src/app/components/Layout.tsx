import { Outlet, Link, useLocation } from "react-router"
import { ShoppingBag, User, Menu, X, Search } from "lucide-react"
import { useState } from "react"

const navLinks = [
  { label: "Trang chủ", to: "/" },
  { label: "Thực đơn", to: "/menu" },
  { label: "Đặt chỗ", to: "/cart" },
  { label: "Về chúng tôi", to: "/#about" },
  { label: "Liên hệ", to: "/#contact" },
]

export function Layout() {
  const [mobileOpen, setMobileOpen] = useState(false)
  const location = useLocation()

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-background/95 backdrop-blur border-b border-border">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3 group">
            <div className="w-9 h-9 rounded-full bg-[#1A1A1A] flex items-center justify-center">
              <span className="text-[#F7F3EC] text-sm font-serif">御</span>
            </div>
            <div>
              <div className="font-serif text-base font-semibold text-foreground leading-none tracking-wide">OMAKASE</div>
              <div className="text-[10px] tracking-[0.2em] text-muted-foreground uppercase">Online</div>
            </div>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                className={`text-sm tracking-wide transition-colors ${
                  location.pathname === link.to
                    ? "text-[#8C2F2F] font-medium"
                    : "text-foreground/70 hover:text-foreground"
                }`}
              >
                {link.label}
              </Link>
            ))}
          </nav>

          {/* Icons */}
          <div className="flex items-center gap-4">
            <Link to="/search" className="text-foreground/60 hover:text-foreground transition-colors">
              <Search size={18} />
            </Link>
            <Link to="/cart" className="text-foreground/60 hover:text-foreground transition-colors">
              <ShoppingBag size={18} />
            </Link>
            <Link to="/profile" className="text-foreground/60 hover:text-foreground transition-colors">
              <User size={18} />
            </Link>
            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="md:hidden text-foreground/60 hover:text-foreground transition-colors"
            >
              {mobileOpen ? <X size={18} /> : <Menu size={18} />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileOpen && (
          <div className="md:hidden border-t border-border bg-background px-6 py-4 flex flex-col gap-4">
            {navLinks.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                onClick={() => setMobileOpen(false)}
                className="text-sm text-foreground/70 hover:text-foreground tracking-wide transition-colors"
              >
                {link.label}
              </Link>
            ))}
          </div>
        )}
      </header>

      {/* Page content */}
      <main className="flex-1">
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="bg-[#1A1A1A] text-[#D8CFC0]">
        <div className="max-w-7xl mx-auto px-6 py-16">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
            {/* Brand */}
            <div className="md:col-span-2">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-full bg-[#8C2F2F] flex items-center justify-center">
                  <span className="text-[#F7F3EC] text-base font-serif">御</span>
                </div>
                <div>
                  <div className="font-serif text-lg font-semibold text-[#F7F3EC] tracking-wide">OMAKASE</div>
                  <div className="text-[10px] tracking-[0.2em] text-[#6B5E50] uppercase">Online</div>
                </div>
              </div>
              <p className="text-sm leading-relaxed text-[#6B5E50] max-w-xs">
                Trải nghiệm ẩm thực Omakase đích thực — nơi đầu bếp dẫn dắt từng khoảnh khắc bằng nguyên liệu tươi ngon nhất.
              </p>
            </div>

            {/* Contact */}
            <div>
              <h4 className="text-xs tracking-[0.2em] uppercase text-[#8C2F2F] mb-4">Liên hệ</h4>
              <div className="flex flex-col gap-2 text-sm text-[#6B5E50]">
                <span>12 Lê Thánh Tôn, Q.1, TP.HCM</span>
                <span>+84 28 3822 4567</span>
                <span>hello@omakase.vn</span>
              </div>
            </div>

            {/* Hours */}
            <div>
              <h4 className="text-xs tracking-[0.2em] uppercase text-[#8C2F2F] mb-4">Giờ mở cửa</h4>
              <div className="flex flex-col gap-2 text-sm text-[#6B5E50]">
                <div className="flex justify-between gap-4">
                  <span>Thứ 3 – Thứ 6</span>
                  <span>11:30 – 22:00</span>
                </div>
                <div className="flex justify-between gap-4">
                  <span>Thứ 7 – CN</span>
                  <span>11:00 – 22:30</span>
                </div>
                <div className="flex justify-between gap-4">
                  <span>Thứ 2</span>
                  <span className="text-[#8C2F2F]">Nghỉ</span>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-12 pt-8 border-t border-[#2A2A2A] flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-xs text-[#3A3A3A]">© 2025 Omakase Online. All rights reserved.</p>
            <div className="flex gap-6">
              {["Facebook", "Instagram", "TikTok"].map((s) => (
                <a key={s} href="#" className="text-xs text-[#3A3A3A] hover:text-[#D8CFC0] transition-colors tracking-wide">
                  {s}
                </a>
              ))}
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
