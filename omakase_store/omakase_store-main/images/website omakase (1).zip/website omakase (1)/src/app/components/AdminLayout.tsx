import { Outlet, Link, useLocation } from "react-router"
import {
  LayoutDashboard,
  UtensilsCrossed,
  Users,
  ClipboardList,
  BarChart2,
  LogOut,
  ChevronRight,
} from "lucide-react"

const adminNav = [
  { label: "Dashboard", to: "/admin", icon: LayoutDashboard },
  { label: "Thực đơn", to: "/admin/products", icon: UtensilsCrossed },
  { label: "Người dùng", to: "/admin/users", icon: Users },
  { label: "Đơn hàng", to: "/admin/orders", icon: ClipboardList },
  { label: "Báo cáo", to: "/admin/reports", icon: BarChart2 },
]

export function AdminLayout() {
  const location = useLocation()

  return (
    <div className="min-h-screen flex bg-[#F0EDE6]">
      {/* Sidebar */}
      <aside className="w-60 bg-[#1A1A1A] flex flex-col fixed inset-y-0 left-0 z-40">
        {/* Logo */}
        <div className="px-6 py-6 border-b border-[#2A2A2A]">
          <Link to="/" className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-[#8C2F2F] flex items-center justify-center">
              <span className="text-[#F7F3EC] text-sm font-serif">御</span>
            </div>
            <div>
              <div className="font-serif text-sm font-semibold text-[#F7F3EC] tracking-wide">OMAKASE</div>
              <div className="text-[9px] tracking-[0.2em] text-[#4A4A4A] uppercase">Admin</div>
            </div>
          </Link>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-3 py-6 flex flex-col gap-1">
          {adminNav.map(({ label, to, icon: Icon }) => {
            const active = location.pathname === to || (to !== "/admin" && location.pathname.startsWith(to))
            return (
              <Link
                key={to}
                to={to}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-sm text-sm transition-colors group ${
                  active
                    ? "bg-[#8C2F2F] text-[#F7F3EC]"
                    : "text-[#6B6B6B] hover:bg-[#2A2A2A] hover:text-[#D8CFC0]"
                }`}
              >
                <Icon size={16} className="shrink-0" />
                <span className="tracking-wide">{label}</span>
                {active && <ChevronRight size={14} className="ml-auto" />}
              </Link>
            )
          })}
        </nav>

        {/* Footer */}
        <div className="px-3 py-4 border-t border-[#2A2A2A]">
          <div className="flex items-center gap-3 px-3 py-2 mb-2">
            <div className="w-7 h-7 rounded-full bg-[#4A3324] flex items-center justify-center text-[#D8CFC0] text-xs font-medium">A</div>
            <div>
              <div className="text-[#D8CFC0] text-xs font-medium">Admin</div>
              <div className="text-[#4A4A4A] text-[10px]">admin@omakase.vn</div>
            </div>
          </div>
          <Link to="/login" className="flex items-center gap-3 px-3 py-2.5 rounded-sm text-sm text-[#6B6B6B] hover:bg-[#2A2A2A] hover:text-[#D8CFC0] transition-colors">
            <LogOut size={16} />
            <span>Đăng xuất</span>
          </Link>
        </div>
      </aside>

      {/* Main content */}
      <div className="ml-60 flex-1 min-h-screen">
        <Outlet />
      </div>
    </div>
  )
}
