import { createBrowserRouter } from "react-router"
import { Layout } from "./components/Layout"
import { AdminLayout } from "./components/AdminLayout"
import { Home } from "./pages/Home"
import { Login } from "./pages/Login"
import { Register } from "./pages/Register"
import { Listing } from "./pages/Listing"
import { Search } from "./pages/Search"
import { Detail } from "./pages/Detail"
import { Cart } from "./pages/Cart"
import { Profile } from "./pages/Profile"
import { OrderHistory } from "./pages/OrderHistory"
import { Dashboard } from "./pages/admin/Dashboard"
import { Products } from "./pages/admin/Products"
import { Users } from "./pages/admin/Users"
import { Orders } from "./pages/admin/Orders"
import { Reports } from "./pages/admin/Reports"

export const router = createBrowserRouter([
  {
    Component: Layout,
    children: [
      { index: true, Component: Home },
      { path: "menu", Component: Listing },
      { path: "menu/:id", Component: Detail },
      { path: "search", Component: Search },
      { path: "cart", Component: Cart },
      { path: "profile", Component: Profile },
      { path: "profile/orders", Component: OrderHistory },
    ],
  },
  {
    path: "login",
    Component: Login,
  },
  {
    path: "register",
    Component: Register,
  },
  {
    path: "admin",
    Component: AdminLayout,
    children: [
      { index: true, Component: Dashboard },
      { path: "products", Component: Products },
      { path: "users", Component: Users },
      { path: "orders", Component: Orders },
      { path: "reports", Component: Reports },
    ],
  },
])
