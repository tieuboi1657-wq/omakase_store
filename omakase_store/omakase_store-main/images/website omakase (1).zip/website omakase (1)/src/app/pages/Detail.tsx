import { Link } from "react-router"
import { useState } from "react"
import { Star, Minus, Plus, ShoppingBag, Calendar, ChevronLeft } from "lucide-react"

const dishes = [
  "Appetizer: Chawanmushi trứng hấp",
  "Amuse-bouche: Tuna tataki",
  "Nigiri 1: Otoro — cá ngừ béo",
  "Nigiri 2: Uni — nhím biển",
  "Nigiri 3: Engawa — vây cá bơn",
  "Nigiri 4: Ikura — trứng cá hồi",
  "Nigiri 5: Aji — cá thu nhật",
  "Sashimi: Hamachi vàng",
  "Maki: Dragon roll đặc biệt",
  "Dessert: Mochi matcha + sake",
]

const reviews = [
  { name: "Nguyễn Thị Mai", rating: 5, date: "15/09/2025", text: "Trải nghiệm tuyệt vời, đầu bếp Tanaka rất tận tâm. Từng món đều chính xác về nhiệt độ và kết cấu.", avatar: "M" },
  { name: "Trần Văn Hùng", rating: 5, date: "02/09/2025", text: "Đây là lần thứ ba tôi quay lại. Omakase Shun luôn đáng đồng tiền. Highly recommended!", avatar: "H" },
  { name: "Lê Thu Hương", rating: 4, date: "28/08/2025", text: "Không gian yên tĩnh, phục vụ ân cần. Chỉ tiếc là phải đặt trước 2 tuần.", avatar: "H" },
]

const thumbnails = [
  "https://images.unsplash.com/photo-1617196034183-421b4040ed20?w=200&h=150&fit=crop&auto=format",
  "https://images.unsplash.com/photo-1611143669185-af224c5e3252?w=200&h=150&fit=crop&auto=format",
  "https://images.unsplash.com/photo-1553621042-f6e147245754?w=200&h=150&fit=crop&auto=format",
  "https://images.unsplash.com/photo-1559410545-0bdcd187e0a6?w=200&h=150&fit=crop&auto=format",
]

export function Detail() {
  const [qty, setQty] = useState(1)
  const [activeImg, setActiveImg] = useState(0)
  const [activeTab, setActiveTab] = useState("desc")

  const tabs = [
    { id: "desc", label: "Mô tả chi tiết" },
    { id: "chef", label: "Thông tin đầu bếp" },
    { id: "reviews", label: `Đánh giá (${reviews.length})` },
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Breadcrumb */}
      <div className="border-b border-border">
        <div className="max-w-7xl mx-auto px-6 py-3 flex items-center gap-2 text-xs text-muted-foreground">
          <Link to="/" className="hover:text-foreground">Trang chủ</Link>
          <span>/</span>
          <Link to="/menu" className="hover:text-foreground">Thực đơn</Link>
          <span>/</span>
          <span className="text-foreground">Omakase Shun</span>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-12">
        {/* Main 2-col */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-14">
          {/* Left: Gallery */}
          <div>
            <div className="bg-muted aspect-[4/3] overflow-hidden mb-4">
              <img
                src={thumbnails[activeImg].replace("200&h=150", "800&h=600")}
                alt="Omakase Shun"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="flex gap-3">
              {thumbnails.map((thumb, i) => (
                <button
                  key={i}
                  onClick={() => setActiveImg(i)}
                  className={`w-20 h-14 overflow-hidden border-2 transition-colors ${
                    activeImg === i ? "border-[#8C2F2F]" : "border-border hover:border-muted-foreground"
                  }`}
                >
                  <img src={thumb} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          </div>

          {/* Right: Info */}
          <div>
            <p className="text-[10px] tracking-[0.3em] uppercase text-muted-foreground mb-2">Nigiri · 10 món · Chef Tanaka Hiroshi</p>
            <h1
              className="font-serif text-4xl font-light mb-4"
              style={{ fontFamily: "'Shippori Mincho', serif" }}
            >
              Omakase Shun
            </h1>
            <div className="flex items-center gap-2 mb-4">
              <div className="flex">
                {[1,2,3,4,5].map((s) => (
                  <Star key={s} size={14} className={s <= 5 ? "fill-[#8C2F2F] text-[#8C2F2F]" : "text-border"} />
                ))}
              </div>
              <span className="text-sm font-medium">4.9</span>
              <span className="text-sm text-muted-foreground">(128 đánh giá)</span>
            </div>

            <div className="text-3xl font-light text-foreground mb-6">
              1.850.000₫
              <span className="text-base text-muted-foreground ml-2">/ người</span>
            </div>

            <div className="w-full h-px bg-border mb-6" />

            <p className="text-muted-foreground leading-relaxed mb-6 text-sm">
              Omakase Shun là hành trình ẩm thực 10 món được tuyển chọn theo mùa vụ. Chef Tanaka Hiroshi sẽ dẫn dắt bạn qua từng hương vị đặc sắc nhất của Nhật Bản — từ otoro béo ngậy đến uni tươi sống mịn màng.
            </p>

            {/* Dishes list */}
            <div className="mb-6">
              <p className="text-xs tracking-[0.2em] uppercase text-foreground mb-3">Các món trong set</p>
              <div className="flex flex-col gap-2">
                {dishes.map((dish, i) => (
                  <div key={i} className="flex items-center gap-3 text-sm text-muted-foreground">
                    <div className="w-5 h-5 rounded-full border border-[#8C2F2F]/40 flex items-center justify-center shrink-0">
                      <span className="text-[9px] text-[#8C2F2F] font-medium">{i + 1}</span>
                    </div>
                    {dish}
                  </div>
                ))}
              </div>
            </div>

            <div className="w-full h-px bg-border mb-6" />

            {/* Quantity */}
            <div className="flex items-center gap-6 mb-6">
              <p className="text-xs tracking-wide text-foreground">Số suất:</p>
              <div className="flex items-center border border-border">
                <button onClick={() => setQty(Math.max(1, qty - 1))} className="px-3 py-2 hover:bg-muted transition-colors">
                  <Minus size={14} />
                </button>
                <span className="px-5 py-2 text-sm font-medium border-x border-border">{qty}</span>
                <button onClick={() => setQty(qty + 1)} className="px-3 py-2 hover:bg-muted transition-colors">
                  <Plus size={14} />
                </button>
              </div>
              <span className="text-sm text-muted-foreground">
                = {(1850000 * qty).toLocaleString("vi-VN")}₫
              </span>
            </div>

            {/* CTAs */}
            <div className="flex gap-3">
              <Link to="/cart" className="flex-1 bg-[#8C2F2F] text-[#F7F3EC] py-3.5 text-sm tracking-widest uppercase hover:bg-[#7A2828] transition-colors flex items-center justify-center gap-2">
                <Calendar size={16} /> Đặt ngay
              </Link>
              <button className="flex-1 border border-border py-3.5 text-sm tracking-widest uppercase hover:bg-muted transition-colors flex items-center justify-center gap-2">
                <ShoppingBag size={16} /> Thêm vào giỏ
              </button>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="mt-20">
          <div className="flex border-b border-border">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-6 py-4 text-sm tracking-wide transition-colors ${
                  activeTab === tab.id
                    ? "border-b-2 border-[#8C2F2F] text-[#8C2F2F] -mb-px"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <div className="py-10">
            {activeTab === "desc" && (
              <div className="max-w-2xl">
                <h3 className="font-serif text-xl font-light mb-4" style={{ fontFamily: "'Shippori Mincho', serif" }}>Về Omakase Shun</h3>
                <p className="text-muted-foreground leading-relaxed mb-4">
                  "Shun" (旬) trong tiếng Nhật có nghĩa là "đúng mùa" — thời điểm nguyên liệu đạt đỉnh hương vị và dinh dưỡng. Omakase Shun được thiết kế để tôn vinh triết lý đó, với toàn bộ nguyên liệu được nhập từ Nhật Bản và các vùng biển ôn đới chọn lọc.
                </p>
                <p className="text-muted-foreground leading-relaxed mb-4">
                  Set bao gồm 10 món theo thứ tự từ thanh nhẹ đến đậm đà — mỗi món là một câu chuyện về biển cả và con người chăm chút từng nguyên liệu.
                </p>
                <p className="text-muted-foreground leading-relaxed">
                  <span className="text-foreground font-medium">Lưu ý:</span> Set này dành cho 1 người. Khách cần đặt trước ít nhất 24 giờ. Không phù hợp với người dị ứng hải sản.
                </p>
              </div>
            )}

            {activeTab === "chef" && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-start max-w-3xl">
                <img
                  src="https://images.unsplash.com/photo-1472926373053-51f48c7cd8a8?w=500&h=600&fit=crop&auto=format"
                  alt="Chef Tanaka Hiroshi"
                  className="w-full aspect-[3/4] object-cover"
                />
                <div>
                  <p className="text-[10px] tracking-[0.3em] uppercase text-[#8C2F2F] mb-2">Bếp trưởng</p>
                  <h3 className="font-serif text-2xl font-light mb-4" style={{ fontFamily: "'Shippori Mincho', serif" }}>
                    Tanaka Hiroshi
                  </h3>
                  <div className="w-8 h-px bg-[#8C2F2F] mb-4" />
                  <p className="text-muted-foreground leading-relaxed text-sm mb-4">
                    Chef Tanaka có hơn 22 năm kinh nghiệm trong nghệ thuật làm sushi, tốt nghiệp từ trường ẩm thực Tsuji tại Osaka và từng làm việc tại Tokyo, Kyoto, Singapore trước khi về Việt Nam.
                  </p>
                  <p className="text-muted-foreground leading-relaxed text-sm">
                    Triết lý của ông: "Sushi ngon nhất là sushi đơn giản nhất — nguyên liệu tươi, kỹ thuật thuần thục, và trái tim hiện diện."
                  </p>
                </div>
              </div>
            )}

            {activeTab === "reviews" && (
              <div className="max-w-2xl flex flex-col gap-8">
                {reviews.map((rev, i) => (
                  <div key={i} className="border-b border-border pb-8 last:border-0">
                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 rounded-full bg-[#4A3324] text-[#D8CFC0] flex items-center justify-center font-medium shrink-0">
                        {rev.avatar}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-medium text-sm">{rev.name}</span>
                          <span className="text-xs text-muted-foreground">{rev.date}</span>
                        </div>
                        <div className="flex mb-3">
                          {[1,2,3,4,5].map((s) => (
                            <Star key={s} size={12} className={s <= rev.rating ? "fill-[#8C2F2F] text-[#8C2F2F]" : "text-border"} />
                          ))}
                        </div>
                        <p className="text-sm text-muted-foreground leading-relaxed">{rev.text}</p>
                      </div>
                    </div>
                  </div>
                ))}
                <button className="text-sm text-[#8C2F2F] hover:underline">Xem thêm đánh giá →</button>
              </div>
            )}
          </div>
        </div>

        {/* Back link */}
        <Link to="/menu" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors mt-4">
          <ChevronLeft size={16} /> Quay lại thực đơn
        </Link>
      </div>
    </div>
  )
}
