import { Users, ShoppingBag, UtensilsCrossed, TrendingUp } from "lucide-react"
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
} from "recharts"

const stats = [
  { label: "Tổng khách hàng", value: "1,248", delta: "+12%", icon: Users, color: "bg-blue-50 text-blue-600" },
  { label: "Tổng đơn / đặt chỗ", value: "3,874", delta: "+8%", icon: ShoppingBag, color: "bg-amber-50 text-amber-600" },
  { label: "Set đang bán", value: "24", delta: "+2", icon: UtensilsCrossed, color: "bg-green-50 text-green-700" },
  { label: "Doanh thu tháng", value: "284,5tr", delta: "+18%", icon: TrendingUp, color: "bg-red-50 text-[#8C2F2F]" },
]

const revenueData = [
  { month: "T4", revenue: 185, orders: 210 },
  { month: "T5", revenue: 210, orders: 245 },
  { month: "T6", revenue: 195, orders: 228 },
  { month: "T7", revenue: 240, orders: 278 },
  { month: "T8", revenue: 268, orders: 305 },
  { month: "T9", revenue: 284, orders: 322 },
]

const recentOrders = [
  { id: "OMK-1024", customer: "Nguyễn Thị Mai", set: "Omakase Shun × 2", time: "22/09 · 20:00", total: "3.700.000₫", status: "Đang xử lý" },
  { id: "OMK-1023", customer: "Trần Văn Hùng", set: "Omakase Yuki × 1", time: "22/09 · 18:30", total: "4.200.000₫", status: "Hoàn tất" },
  { id: "OMK-1022", customer: "Lê Thu Hương", set: "Set Trưa Hana × 3", time: "22/09 · 12:00", total: "2.040.000₫", status: "Hoàn tất" },
  { id: "OMK-1021", customer: "Phạm Minh Tuấn", set: "Nigiri Kaiseki × 2", time: "21/09 · 19:30", total: "2.900.000₫", status: "Hoàn tất" },
  { id: "OMK-1020", customer: "Võ Thị Lan", set: "Omakase Sakura × 1", time: "21/09 · 18:00", total: "2.950.000₫", status: "Đã hủy" },
]

const statusColors: Record<string, string> = {
  "Hoàn tất": "bg-green-100 text-green-700",
  "Đang xử lý": "bg-amber-100 text-amber-700",
  "Đã hủy": "bg-red-100 text-red-700",
}

export function Dashboard() {
  return (
    <div className="p-8 min-h-screen bg-[#F0EDE6]">
      {/* Header */}
      <div className="mb-8">
        <p className="text-xs tracking-[0.2em] uppercase text-[#8C2F2F] mb-1">Tổng quan</p>
        <h1 className="font-serif text-3xl font-light text-foreground" style={{ fontFamily: "'Shippori Mincho', serif" }}>
          Dashboard
        </h1>
        <p className="text-sm text-muted-foreground mt-1">Thứ Hai, 22 tháng 9 năm 2025</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {stats.map((stat) => (
          <div key={stat.label} className="bg-card border border-border p-5">
            <div className="flex items-start justify-between mb-4">
              <div className={`w-9 h-9 rounded-sm flex items-center justify-center ${stat.color}`}>
                <stat.icon size={18} />
              </div>
              <span className="text-xs text-green-600 font-medium">{stat.delta}</span>
            </div>
            <p className="text-2xl font-light font-serif mb-1" style={{ fontFamily: "'Shippori Mincho', serif" }}>
              {stat.value}
            </p>
            <p className="text-xs text-muted-foreground">{stat.label}</p>
          </div>
        ))}
      </div>

      {/* Charts + Recent orders */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Revenue chart */}
        <div className="xl:col-span-2 bg-card border border-border p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-sm font-medium">Doanh thu 6 tháng gần đây</h2>
            <span className="text-xs text-muted-foreground">(triệu VND)</span>
          </div>
          <ResponsiveContainer width="100%" height={240}>
            <LineChart data={revenueData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#D8CFC0" />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: "#6B5E50" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: "#6B5E50" }} axisLine={false} tickLine={false} />
              <Tooltip
                contentStyle={{ background: "#1A1A1A", border: "none", borderRadius: 0, color: "#F7F3EC", fontSize: 12 }}
                formatter={(v: number) => [`${v}tr`, "Doanh thu"]}
              />
              <Line type="monotone" dataKey="revenue" stroke="#8C2F2F" strokeWidth={2} dot={{ fill: "#8C2F2F", r: 4 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Orders chart */}
        <div className="bg-card border border-border p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-sm font-medium">Số đơn</h2>
            <span className="text-xs text-muted-foreground">6 tháng</span>
          </div>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={revenueData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#D8CFC0" />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: "#6B5E50" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: "#6B5E50" }} axisLine={false} tickLine={false} />
              <Tooltip
                contentStyle={{ background: "#1A1A1A", border: "none", borderRadius: 0, color: "#F7F3EC", fontSize: 12 }}
              />
              <Bar dataKey="orders" fill="#4A3324" radius={[2, 2, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Recent Orders table */}
      <div className="mt-6 bg-card border border-border">
        <div className="px-6 py-4 border-b border-border flex items-center justify-between">
          <h2 className="text-sm font-medium">Đơn hàng gần đây</h2>
          <a href="/admin/orders" className="text-xs text-[#8C2F2F] hover:underline">Xem tất cả →</a>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border bg-[#F7F3EC]">
                {["Mã đơn", "Khách hàng", "Set đã đặt", "Thời gian", "Tổng tiền", "Trạng thái"].map((h) => (
                  <th key={h} className="px-5 py-3 text-left text-xs tracking-wide text-muted-foreground font-normal">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {recentOrders.map((order, i) => (
                <tr key={order.id} className={`${i < recentOrders.length - 1 ? "border-b border-border" : ""} hover:bg-muted/30 transition-colors`}>
                  <td className="px-5 py-4 font-mono text-xs text-muted-foreground">{order.id}</td>
                  <td className="px-5 py-4 text-sm">{order.customer}</td>
                  <td className="px-5 py-4 text-sm text-muted-foreground">{order.set}</td>
                  <td className="px-5 py-4 text-xs text-muted-foreground">{order.time}</td>
                  <td className="px-5 py-4 text-sm font-medium">{order.total}</td>
                  <td className="px-5 py-4">
                    <span className={`text-[10px] font-medium px-2 py-1 rounded-full ${statusColors[order.status]}`}>
                      {order.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
