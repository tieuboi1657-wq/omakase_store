import { Link } from "react-router"
import { useState } from "react"
import { Minus, Plus, X, Calendar, Clock, Users, ArrowRight } from "lucide-react"

const initialItems = [
  { id: "1", name: "Omakase Shun", subtitle: "10 món theo mùa", price: 1850000, qty: 2, img: "https://images.unsplash.com/photo-1617196034183-421b4040ed20?w=100&h=80&fit=crop&auto=format" },
  { id: "3", name: "Set Trưa Hana", subtitle: "5 món + miso soup", price: 680000, qty: 1, img: "https://images.unsplash.com/photo-1559410545-0bdcd187e0a6?w=100&h=80&fit=crop&auto=format" },
]

const timeSlots = ["11:30", "12:00", "12:30", "17:30", "18:00", "18:30", "19:00", "19:30", "20:00", "20:30"]

export function Cart() {
  const [items, setItems] = useState(initialItems)
  const [date, setDate] = useState("")
  const [selectedTime, setSelectedTime] = useState("")
  const [guests, setGuests] = useState(2)

  const updateQty = (id: string, delta: number) => {
    setItems((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, qty: Math.max(1, item.qty + delta) } : item
      )
    )
  }
  const removeItem = (id: string) => setItems((prev) => prev.filter((item) => item.id !== id))

  const subtotal = items.reduce((sum, item) => sum + item.price * item.qty, 0)
  const serviceFee = Math.round(subtotal * 0.05)
  const total = subtotal + serviceFee

  return (
    <div className="min-h-screen bg-background">
      {/* Breadcrumb */}
      <div className="border-b border-border">
        <div className="max-w-7xl mx-auto px-6 py-3">
          <p className="text-xs text-muted-foreground">
            <Link to="/" className="hover:text-foreground">Trang chủ</Link>
            <span className="mx-2">/</span>
            <span className="text-foreground">Giỏ hàng & Đặt chỗ</span>
          </p>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-6 py-12">
        <p className="text-xs tracking-[0.3em] uppercase text-[#8C2F2F] mb-2">Đặt suất Omakase</p>
        <h1 className="font-serif text-3xl font-light mb-10" style={{ fontFamily: "'Shippori Mincho', serif" }}>
          Giỏ hàng & Thông tin đặt chỗ
        </h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
          {/* Left: Cart + Booking info */}
          <div className="lg:col-span-2 flex flex-col gap-8">
            {/* Cart table */}
            <div>
              <h2 className="text-sm font-medium tracking-wide mb-4">Các set đã chọn</h2>
              <div className="border border-border">
                {/* Header */}
                <div className="hidden md:grid grid-cols-[2fr_1fr_1fr_1fr_auto] gap-4 px-5 py-3 bg-muted text-xs tracking-wide text-muted-foreground border-b border-border">
                  <span>Set / Món</span>
                  <span className="text-right">Đơn giá</span>
                  <span className="text-center">Số lượng</span>
                  <span className="text-right">Thành tiền</span>
                  <span></span>
                </div>

                {items.map((item, i) => (
                  <div key={item.id} className={`grid grid-cols-[2fr_1fr_1fr_1fr_auto] items-center gap-4 px-5 py-4 ${i < items.length - 1 ? "border-b border-border" : ""}`}>
                    <div className="flex items-center gap-3">
                      <img src={item.img} alt={item.name} className="w-14 h-10 object-cover shrink-0 bg-muted" />
                      <div>
                        <p className="text-sm font-medium">{item.name}</p>
                        <p className="text-xs text-muted-foreground">{item.subtitle}</p>
                      </div>
                    </div>
                    <p className="text-sm text-right">{item.price.toLocaleString("vi-VN")}₫</p>
                    <div className="flex items-center justify-center border border-border">
                      <button onClick={() => updateQty(item.id, -1)} className="px-2 py-1 hover:bg-muted transition-colors">
                        <Minus size={12} />
                      </button>
                      <span className="px-3 py-1 text-sm border-x border-border min-w-[32px] text-center">{item.qty}</span>
                      <button onClick={() => updateQty(item.id, 1)} className="px-2 py-1 hover:bg-muted transition-colors">
                        <Plus size={12} />
                      </button>
                    </div>
                    <p className="text-sm font-medium text-right">{(item.price * item.qty).toLocaleString("vi-VN")}₫</p>
                    <button onClick={() => removeItem(item.id)} className="text-muted-foreground hover:text-foreground transition-colors">
                      <X size={16} />
                    </button>
                  </div>
                ))}
              </div>

              <Link to="/menu" className="inline-flex items-center gap-2 text-xs text-[#8C2F2F] mt-4 hover:underline">
                + Tiếp tục chọn thực đơn
              </Link>
            </div>

            {/* Booking info */}
            <div>
              <h2 className="text-sm font-medium tracking-wide mb-4">Thông tin đặt chỗ</h2>
              <div className="border border-border p-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {/* Date */}
                  <div>
                    <label className="flex items-center gap-2 text-xs tracking-wide text-foreground mb-2">
                      <Calendar size={14} /> Ngày đặt bàn
                    </label>
                    <input
                      type="date"
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                      min={new Date().toISOString().split("T")[0]}
                      className="w-full border border-border bg-background px-3 py-2.5 text-sm outline-none focus:border-[#8C2F2F] transition-colors"
                    />
                  </div>

                  {/* Guests */}
                  <div>
                    <label className="flex items-center gap-2 text-xs tracking-wide text-foreground mb-2">
                      <Users size={14} /> Số lượng khách
                    </label>
                    <div className="flex items-center border border-border">
                      <button onClick={() => setGuests(Math.max(1, guests - 1))} className="px-3 py-2.5 hover:bg-muted transition-colors">
                        <Minus size={14} />
                      </button>
                      <span className="flex-1 text-center text-sm font-medium border-x border-border py-2.5">{guests} người</span>
                      <button onClick={() => setGuests(Math.min(10, guests + 1))} className="px-3 py-2.5 hover:bg-muted transition-colors">
                        <Plus size={14} />
                      </button>
                    </div>
                  </div>

                  {/* Time */}
                  <div className="md:col-span-3">
                    <label className="flex items-center gap-2 text-xs tracking-wide text-foreground mb-2">
                      <Clock size={14} /> Giờ đặt
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {timeSlots.map((time) => (
                        <button
                          key={time}
                          onClick={() => setSelectedTime(time)}
                          className={`px-4 py-2 text-sm border transition-colors ${
                            selectedTime === time
                              ? "bg-[#8C2F2F] text-[#F7F3EC] border-[#8C2F2F]"
                              : "border-border text-muted-foreground hover:border-[#8C2F2F] hover:text-foreground"
                          }`}
                        >
                          {time}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right: Summary */}
          <div>
            <div className="border border-border p-6 sticky top-20">
              <h2 className="text-sm font-medium tracking-wide mb-6">Tóm tắt đơn hàng</h2>

              {date && selectedTime && (
                <div className="bg-muted p-3 mb-6 text-xs text-muted-foreground">
                  <p className="font-medium text-foreground mb-1">Thông tin đặt chỗ</p>
                  <p>📅 {date}</p>
                  <p>🕐 {selectedTime}</p>
                  <p>👥 {guests} khách</p>
                </div>
              )}

              <div className="flex flex-col gap-3 mb-6">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Tạm tính</span>
                  <span>{subtotal.toLocaleString("vi-VN")}₫</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Phí phục vụ (5%)</span>
                  <span>{serviceFee.toLocaleString("vi-VN")}₫</span>
                </div>
                <div className="h-px bg-border" />
                <div className="flex justify-between font-medium">
                  <span>Tổng tiền</span>
                  <span>{total.toLocaleString("vi-VN")}₫</span>
                </div>
              </div>

              <button className="w-full bg-[#8C2F2F] text-[#F7F3EC] py-3.5 text-sm tracking-widest uppercase hover:bg-[#7A2828] transition-colors flex items-center justify-center gap-2 mb-3">
                Thanh toán <ArrowRight size={16} />
              </button>
              <Link to="/menu" className="w-full block text-center border border-border py-3 text-sm text-muted-foreground hover:bg-muted transition-colors">
                Tiếp tục xem thực đơn
              </Link>

              <p className="text-[10px] text-muted-foreground text-center mt-4 leading-relaxed">
                Đặt trước 48 giờ để nhận ưu đãi 10%
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
