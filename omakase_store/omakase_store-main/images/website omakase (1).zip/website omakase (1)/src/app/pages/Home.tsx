import { Link } from "react-router"
import { ArrowRight, Search, Star, Clock, MapPin } from "lucide-react"

const categories = [
  { label: "Omakase\nCơ bản", img: "https://images.unsplash.com/photo-1617196034183-421b4040ed20?w=200&h=200&fit=crop&auto=format", count: "8 món" },
  { label: "Omakase\nCao cấp", img: "https://images.unsplash.com/photo-1611143669185-af224c5e3252?w=200&h=200&fit=crop&auto=format", count: "14 món" },
  { label: "Set\nTrưa", img: "https://images.unsplash.com/photo-1559410545-0bdcd187e0a6?w=200&h=200&fit=crop&auto=format", count: "5 món" },
  { label: "Đồ\nUống", img: "https://images.unsplash.com/photo-1544145945-f90425340c7e?w=200&h=200&fit=crop&auto=format", count: "12 loại" },
]

const featured = [
  {
    id: "1",
    name: "Omakase Shun",
    subtitle: "10 món theo mùa",
    price: "1.850.000",
    rating: 4.9,
    reviews: 128,
    img: "https://images.unsplash.com/photo-1617196034183-421b4040ed20?w=600&h=400&fit=crop&auto=format",
    tag: "Bán chạy",
  },
  {
    id: "2",
    name: "Omakase Sakura",
    subtitle: "14 món cao cấp",
    price: "2.950.000",
    rating: 5.0,
    reviews: 84,
    img: "https://images.unsplash.com/photo-1611143669185-af224c5e3252?w=600&h=400&fit=crop&auto=format",
    tag: "Nổi bật",
  },
  {
    id: "3",
    name: "Set Trưa Hana",
    subtitle: "5 món + miso soup",
    price: "680.000",
    rating: 4.8,
    reviews: 203,
    img: "https://images.unsplash.com/photo-1559410545-0bdcd187e0a6?w=600&h=400&fit=crop&auto=format",
    tag: "Giá tốt",
  },
  {
    id: "4",
    name: "Omakase Yuki",
    subtitle: "18 món đặc biệt",
    price: "4.200.000",
    rating: 5.0,
    reviews: 56,
    img: "https://images.unsplash.com/photo-1553621042-f6e147245754?w=600&h=400&fit=crop&auto=format",
    tag: "Premium",
  },
]

export function Home() {
  return (
    <div>
      {/* Hero */}
      <section className="relative h-[92vh] min-h-[600px] overflow-hidden">
        <img
          src="https://images.unsplash.com/photo-1579871494447-9811cf80d66c?w=1800&h=1200&fit=crop&auto=format"
          alt="Đầu bếp chế biến sushi"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#1A1A1A]/50 via-[#1A1A1A]/30 to-[#1A1A1A]/70" />

        <div className="relative h-full flex flex-col items-center justify-center text-center px-6">
          <p className="text-[#D8CFC0] text-xs tracking-[0.4em] uppercase mb-6">
            Nghệ thuật ẩm thực Nhật Bản
          </p>
          <h1
            className="font-serif text-[#F7F3EC] text-5xl md:text-7xl font-light leading-tight mb-6"
            style={{ fontFamily: "'Shippori Mincho', 'Noto Serif JP', serif" }}
          >
            お任せ
            <br />
            <span className="text-3xl md:text-4xl tracking-widest">OMAKASE</span>
          </h1>
          <p className="text-[#D8CFC0] text-base md:text-lg font-light max-w-md leading-relaxed mb-10">
            Để đầu bếp dẫn dắt — từng lát cá, từng khoảnh khắc, từng cảm xúc.
          </p>
          <div className="flex gap-4">
            <Link
              to="/menu"
              className="bg-[#8C2F2F] text-[#F7F3EC] px-8 py-3 text-sm tracking-widest uppercase hover:bg-[#7A2828] transition-colors flex items-center gap-2"
            >
              Xem thực đơn <ArrowRight size={16} />
            </Link>
            <Link
              to="/cart"
              className="border border-[#D8CFC0] text-[#D8CFC0] px-8 py-3 text-sm tracking-widest uppercase hover:bg-[#D8CFC0]/10 transition-colors"
            >
              Đặt bàn
            </Link>
          </div>
        </div>

        {/* Search bar floating */}
        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-1/2 w-full max-w-xl px-6">
          <div className="bg-background shadow-lg border border-border flex items-center gap-3 px-5 py-4">
            <Search size={18} className="text-muted-foreground shrink-0" />
            <input
              type="text"
              placeholder="Tìm set Omakase, món ăn, chi nhánh..."
              className="flex-1 bg-transparent text-sm text-foreground placeholder:text-muted-foreground outline-none"
            />
            <Link to="/search" className="bg-[#8C2F2F] text-[#F7F3EC] px-4 py-2 text-xs tracking-wide uppercase hover:bg-[#7A2828] transition-colors">
              Tìm
            </Link>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="pt-28 pb-20 max-w-7xl mx-auto px-6">
        <div className="text-center mb-14">
          <p className="text-xs tracking-[0.3em] uppercase text-[#8C2F2F] mb-3">Danh mục</p>
          <h2 className="font-serif text-3xl font-light text-foreground" style={{ fontFamily: "'Shippori Mincho', serif" }}>
            Thực đơn của chúng tôi
          </h2>
        </div>
        <div className="flex justify-center gap-8 flex-wrap">
          {categories.map((cat) => (
            <Link key={cat.label} to="/menu" className="group flex flex-col items-center gap-4">
              <div className="w-28 h-28 rounded-full overflow-hidden border-2 border-border group-hover:border-[#8C2F2F] transition-colors bg-muted">
                <img src={cat.img} alt={cat.label} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
              </div>
              <div className="text-center">
                <p className="text-sm font-medium text-foreground whitespace-pre-line leading-tight">{cat.label}</p>
                <p className="text-xs text-muted-foreground mt-1">{cat.count}</p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-20 bg-[#EDE9E0]">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex items-end justify-between mb-12">
            <div>
              <p className="text-xs tracking-[0.3em] uppercase text-[#8C2F2F] mb-3">Nổi bật</p>
              <h2 className="font-serif text-3xl font-light" style={{ fontFamily: "'Shippori Mincho', serif" }}>
                Set Omakase được yêu thích
              </h2>
            </div>
            <Link to="/menu" className="hidden md:flex items-center gap-2 text-sm text-[#8C2F2F] hover:gap-3 transition-all">
              Xem tất cả <ArrowRight size={16} />
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featured.map((item) => (
              <Link key={item.id} to={`/menu/${item.id}`} className="group bg-background overflow-hidden border border-border hover:border-[#8C2F2F]/30 transition-colors">
                <div className="relative overflow-hidden aspect-[4/3] bg-muted">
                  <img
                    src={item.img}
                    alt={item.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute top-3 left-3">
                    <span className="bg-[#8C2F2F] text-[#F7F3EC] text-[10px] tracking-widest uppercase px-2 py-1">
                      {item.tag}
                    </span>
                  </div>
                </div>
                <div className="p-5">
                  <p className="text-[10px] tracking-[0.2em] uppercase text-muted-foreground mb-1">{item.subtitle}</p>
                  <h3 className="font-serif text-lg font-medium text-foreground mb-3" style={{ fontFamily: "'Shippori Mincho', serif" }}>
                    {item.name}
                  </h3>
                  <div className="flex items-center gap-1 mb-4">
                    <Star size={12} className="fill-[#8C2F2F] text-[#8C2F2F]" />
                    <span className="text-xs font-medium">{item.rating}</span>
                    <span className="text-xs text-muted-foreground">({item.reviews})</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="font-medium text-foreground">{item.price}₫</span>
                    <span className="text-[10px] tracking-wide text-[#8C2F2F] uppercase group-hover:underline">Xem chi tiết →</span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Philosophy section */}
      <section className="py-24 max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
          <div>
            <p className="text-xs tracking-[0.3em] uppercase text-[#8C2F2F] mb-4">Triết lý</p>
            <h2
              className="font-serif text-4xl font-light leading-snug mb-6"
              style={{ fontFamily: "'Shippori Mincho', serif" }}
            >
              "Omakase" — <br />
              <em>Tôi phó thác cho bạn</em>
            </h2>
            <div className="w-12 h-px bg-[#8C2F2F] mb-6" />
            <p className="text-muted-foreground leading-relaxed mb-4">
              Omakase là nghệ thuật phó thác — khách tin tưởng đặt bữa ăn vào tay đầu bếp. Mỗi món được cân nhắc theo mùa vụ, theo nguyên liệu tươi nhất trong ngày, theo cảm xúc của đầu bếp dành cho thực khách.
            </p>
            <p className="text-muted-foreground leading-relaxed mb-8">
              Không có thực đơn cố định. Không có sự lặp lại. Mỗi bữa là một tác phẩm độc bản.
            </p>
            <Link to="/menu" className="inline-flex items-center gap-2 text-sm text-foreground border-b border-foreground pb-0.5 hover:text-[#8C2F2F] hover:border-[#8C2F2F] transition-colors">
              Khám phá thực đơn <ArrowRight size={14} />
            </Link>
          </div>
          <div className="relative">
            <img
              src="https://images.unsplash.com/photo-1472926373053-51f48c7cd8a8?w=800&h=900&fit=crop&auto=format"
              alt="Đầu bếp Omakase"
              className="w-full aspect-[3/4] object-cover"
            />
            <div className="absolute -bottom-6 -left-6 bg-[#8C2F2F] text-[#F7F3EC] p-6 max-w-[200px]">
              <p className="font-serif text-2xl font-light mb-1" style={{ fontFamily: "'Shippori Mincho', serif" }}>15+</p>
              <p className="text-xs tracking-wide">Năm kinh nghiệm</p>
            </div>
          </div>
        </div>
      </section>

      {/* Promo Banner */}
      <section className="py-6 bg-[#4A3324]">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <Clock size={20} className="text-[#D8CFC0] shrink-0" />
            <p className="text-[#D8CFC0] text-sm">
              <span className="font-medium text-[#F7F3EC]">Đặt sớm, giảm ngay 10%</span> — Đặt bàn trước 48 giờ để nhận ưu đãi đặc biệt
            </p>
          </div>
          <Link
            to="/cart"
            className="shrink-0 bg-[#8C2F2F] text-[#F7F3EC] px-6 py-2.5 text-xs tracking-widest uppercase hover:bg-[#7A2828] transition-colors"
          >
            Đặt ngay
          </Link>
        </div>
      </section>

      {/* Locations */}
      <section className="py-20 max-w-7xl mx-auto px-6">
        <div className="text-center mb-12">
          <p className="text-xs tracking-[0.3em] uppercase text-[#8C2F2F] mb-3">Chi nhánh</p>
          <h2 className="font-serif text-3xl font-light" style={{ fontFamily: "'Shippori Mincho', serif" }}>
            Tìm chúng tôi
          </h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            { name: "Omakase Lê Thánh Tôn", address: "12 Lê Thánh Tôn, Q.1, TP.HCM", phone: "+84 28 3822 4567" },
            { name: "Omakase Nguyễn Huệ", address: "28 Nguyễn Huệ, Q.1, TP.HCM", phone: "+84 28 3823 5678" },
            { name: "Omakase Hà Nội", address: "15 Tràng Tiền, Hoàn Kiếm, Hà Nội", phone: "+84 24 3826 6789" },
          ].map((loc) => (
            <div key={loc.name} className="border border-border p-6 group hover:border-[#8C2F2F]/40 transition-colors">
              <MapPin size={16} className="text-[#8C2F2F] mb-4" />
              <h3 className="font-serif font-medium mb-2" style={{ fontFamily: "'Shippori Mincho', serif" }}>{loc.name}</h3>
              <p className="text-sm text-muted-foreground mb-1">{loc.address}</p>
              <p className="text-sm text-muted-foreground">{loc.phone}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  )
}
