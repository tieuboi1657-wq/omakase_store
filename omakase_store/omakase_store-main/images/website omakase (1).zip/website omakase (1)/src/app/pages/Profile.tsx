import { Link, useLocation } from "react-router"
import { User, Package, History, Heart, Lock, LogOut } from "lucide-react"
import { useState } from "react"

const sidebarLinks = [
  { label: "Thông tin cá nhân", to: "/profile", icon: User },
  { label: "Đơn hàng", to: "/profile/orders", icon: Package },
  { label: "Lịch sử đặt chỗ", to: "/profile/orders", icon: History },
  { label: "Món yêu thích", to: "/profile", icon: Heart },
  { label: "Đổi mật khẩu", to: "/profile", icon: Lock },
  { label: "Đăng xuất", to: "/login", icon: LogOut },
]

export function Profile() {
  const location = useLocation()
  const [saved, setSaved] = useState(false)

  return (
    <div className="min-h-screen bg-background">
      {/* Breadcrumb */}
      <div className="border-b border-border">
        <div className="max-w-7xl mx-auto px-6 py-3">
          <p className="text-xs text-muted-foreground">
            <Link to="/" className="hover:text-foreground">Trang chủ</Link>
            <span className="mx-2">/</span>
            <span className="text-foreground">Hồ sơ cá nhân</span>
          </p>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-[240px_1fr] gap-10">
          {/* Sidebar */}
          <aside>
            <div className="bg-[#1A1A1A] p-6 text-center mb-1">
              <div className="w-16 h-16 rounded-full bg-[#4A3324] text-[#D8CFC0] flex items-center justify-center text-2xl font-serif mx-auto mb-3">
                N
              </div>
              <p className="text-[#F7F3EC] font-medium text-sm">Nguyễn Thị Mai</p>
              <p className="text-[#6B6B6B] text-xs mt-0.5">mai.nguyen@email.com</p>
            </div>
            <nav className="bg-[#1A1A1A] overflow-hidden">
              {sidebarLinks.map(({ label, to, icon: Icon }, i) => {
                const isActive = location.pathname === to && i < 2
                const isDanger = label === "Đăng xuất"
                return (
                  <Link
                    key={label}
                    to={to}
                    className={`flex items-center gap-3 px-5 py-3.5 text-sm transition-colors border-b border-[#2A2A2A] last:border-0 ${
                      isActive
                        ? "bg-[#8C2F2F] text-[#F7F3EC]"
                        : isDanger
                        ? "text-[#6B6B6B] hover:bg-[#2A2A2A] hover:text-red-400"
                        : "text-[#6B6B6B] hover:bg-[#2A2A2A] hover:text-[#D8CFC0]"
                    }`}
                  >
                    <Icon size={15} className="shrink-0" />
                    {label}
                  </Link>
                )
              })}
            </nav>
          </aside>

          {/* Content */}
          <div>
            <h1 className="font-serif text-2xl font-light mb-1" style={{ fontFamily: "'Shippori Mincho', serif" }}>
              Thông tin cá nhân
            </h1>
            <p className="text-sm text-muted-foreground mb-8">Cập nhật thông tin tài khoản của bạn</p>

            <form
              onSubmit={(e) => { e.preventDefault(); setSaved(true); setTimeout(() => setSaved(false), 2000) }}
              className="max-w-md flex flex-col gap-5"
            >
              <div>
                <label className="block text-xs tracking-wide text-foreground mb-2">Họ và tên</label>
                <input
                  type="text"
                  defaultValue="Nguyễn Thị Mai"
                  className="w-full border border-border bg-white px-4 py-3 text-sm outline-none focus:border-[#8C2F2F] transition-colors"
                />
              </div>
              <div>
                <label className="block text-xs tracking-wide text-foreground mb-2">Email</label>
                <input
                  type="email"
                  defaultValue="mai.nguyen@email.com"
                  className="w-full border border-border bg-white px-4 py-3 text-sm outline-none focus:border-[#8C2F2F] transition-colors"
                />
              </div>
              <div>
                <label className="block text-xs tracking-wide text-foreground mb-2">Số điện thoại</label>
                <input
                  type="tel"
                  defaultValue="0901 234 567"
                  className="w-full border border-border bg-white px-4 py-3 text-sm outline-none focus:border-[#8C2F2F] transition-colors"
                />
              </div>
              <div>
                <label className="block text-xs tracking-wide text-foreground mb-2">Địa chỉ</label>
                <input
                  type="text"
                  defaultValue="45 Nguyễn Trãi, Q.1, TP.HCM"
                  className="w-full border border-border bg-white px-4 py-3 text-sm outline-none focus:border-[#8C2F2F] transition-colors"
                />
              </div>
              <div>
                <label className="block text-xs tracking-wide text-foreground mb-2">Ngày sinh</label>
                <input
                  type="date"
                  defaultValue="1995-04-22"
                  className="w-full border border-border bg-white px-4 py-3 text-sm outline-none focus:border-[#8C2F2F] transition-colors"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className={`px-8 py-3 text-sm tracking-widest uppercase transition-colors ${
                    saved
                      ? "bg-[#4A3324] text-[#F7F3EC] cursor-default"
                      : "bg-[#8C2F2F] text-[#F7F3EC] hover:bg-[#7A2828]"
                  }`}
                >
                  {saved ? "✓ Đã lưu" : "Lưu thay đổi"}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  )
}
