import { Link } from "react-router"
import { useState } from "react"
import { Star, SlidersHorizontal, ChevronDown } from "lucide-react"

const allSets = [
  { id: "1", name: "Omakase Shun", category: "Nigiri", price: 1850000, pieces: 10, chef: "Tanaka Hiroshi", rating: 4.9, reviews: 128, img: "https://images.unsplash.com/photo-1617196034183-421b4040ed20?w=500&h=350&fit=crop&auto=format", status: "Đang bán" },
  { id: "2", name: "Omakase Sakura", category: "Full-course", price: 2950000, pieces: 14, chef: "Yamamoto Kenji", rating: 5.0, reviews: 84, img: "https://images.unsplash.com/photo-1611143669185-af224c5e3252?w=500&h=350&fit=crop&auto=format", status: "Đang bán" },
  { id: "3", name: "Set Trưa Hana", category: "Sashimi", price: 680000, pieces: 5, chef: "Tanaka Hiroshi", rating: 4.8, reviews: 203, img: "https://images.unsplash.com/photo-1559410545-0bdcd187e0a6?w=500&h=350&fit=crop&auto=format", status: "Đang bán" },
  { id: "4", name: "Omakase Yuki", category: "Full-course", price: 4200000, pieces: 18, chef: "Sato Noboru", rating: 5.0, reviews: 56, img: "https://images.unsplash.com/photo-1553621042-f6e147245754?w=500&h=350&fit=crop&auto=format", status: "Đang bán" },
  { id: "5", name: "Chirashi Premium", category: "Chirashi", price: 850000, pieces: 12, chef: "Yamamoto Kenji", rating: 4.7, reviews: 172, img: "https://images.unsplash.com/photo-1569050467447-ce54b3bbc37d?w=500&h=350&fit=crop&auto=format", status: "Đang bán" },
  { id: "6", name: "Nigiri Kaiseki", category: "Nigiri", price: 1450000, pieces: 8, chef: "Sato Noboru", rating: 4.9, reviews: 93, img: "https://images.unsplash.com/photo-1617196034199-ce0d0fd6e34a?w=500&h=350&fit=crop&auto=format", status: "Đang bán" },
  { id: "7", name: "Sashimi Mori", category: "Sashimi", price: 580000, pieces: 10, chef: "Tanaka Hiroshi", rating: 4.8, reviews: 145, img: "https://images.unsplash.com/photo-1580822184713-fc5400e7fe10?w=500&h=350&fit=crop&auto=format", status: "Đang bán" },
  { id: "8", name: "Full Course Haru", category: "Full-course", price: 3600000, pieces: 16, chef: "Sato Noboru", rating: 4.9, reviews: 67, img: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&h=350&fit=crop&auto=format", status: "Đang bán" },
  { id: "9", name: "Omakase Natsu", category: "Full-course", price: 2200000, pieces: 12, chef: "Yamamoto Kenji", rating: 4.8, reviews: 110, img: "https://images.unsplash.com/photo-1617196034302-b6c419a04684?w=500&h=350&fit=crop&auto=format", status: "Đang bán" },
]

const categories = ["Tất cả", "Nigiri", "Sashimi", "Chirashi", "Full-course"]
const chefs = ["Tất cả đầu bếp", "Tanaka Hiroshi", "Yamamoto Kenji", "Sato Noboru"]
const sorts = ["Phổ biến nhất", "Giá tăng dần", "Giá giảm dần", "Đánh giá cao"]

export function Listing() {
  const [selectedCat, setSelectedCat] = useState("Tất cả")
  const [selectedChef, setSelectedChef] = useState("Tất cả đầu bếp")
  const [priceRange, setPriceRange] = useState([0, 5000000])
  const [sort, setSort] = useState("Phổ biến nhất")
  const [page, setPage] = useState(1)
  const [showFilter, setShowFilter] = useState(false)

  const filtered = allSets.filter((s) => {
    if (selectedCat !== "Tất cả" && s.category !== selectedCat) return false
    if (selectedChef !== "Tất cả đầu bếp" && s.chef !== selectedChef) return false
    if (s.price < priceRange[0] || s.price > priceRange[1]) return false
    return true
  }).sort((a, b) => {
    if (sort === "Giá tăng dần") return a.price - b.price
    if (sort === "Giá giảm dần") return b.price - a.price
    if (sort === "Đánh giá cao") return b.rating - a.rating
    return b.reviews - a.reviews
  })

  const perPage = 6
  const totalPages = Math.ceil(filtered.length / perPage)
  const displayed = filtered.slice((page - 1) * perPage, page * perPage)

  return (
    <div className="min-h-screen bg-background">
      {/* Breadcrumb */}
      <div className="border-b border-border">
        <div className="max-w-7xl mx-auto px-6 py-3">
          <p className="text-xs text-muted-foreground">
            <Link to="/" className="hover:text-foreground">Trang chủ</Link>
            <span className="mx-2">/</span>
            <span className="text-foreground">Thực đơn</span>
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-10">
        <div className="flex gap-10">
          {/* Sidebar filter */}
          <aside className={`${showFilter ? "block" : "hidden"} md:block w-56 shrink-0`}>
            <div className="sticky top-20">
              <h3 className="text-xs tracking-[0.2em] uppercase text-[#8C2F2F] mb-5">Bộ lọc</h3>

              {/* Category */}
              <div className="mb-6">
                <h4 className="text-xs font-medium text-foreground mb-3">Loại set</h4>
                <div className="flex flex-col gap-2">
                  {categories.map((cat) => (
                    <button
                      key={cat}
                      onClick={() => setSelectedCat(cat)}
                      className={`text-sm text-left px-3 py-1.5 transition-colors ${
                        selectedCat === cat
                          ? "bg-[#8C2F2F] text-[#F7F3EC]"
                          : "text-muted-foreground hover:text-foreground hover:bg-muted"
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              {/* Price range */}
              <div className="mb-6">
                <h4 className="text-xs font-medium text-foreground mb-3">Khoảng giá</h4>
                <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2">
                  <span>{(priceRange[0] / 1000).toFixed(0)}k</span>
                  <span>—</span>
                  <span>{(priceRange[1] / 1000).toFixed(0)}k</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={5000000}
                  step={100000}
                  value={priceRange[1]}
                  onChange={(e) => setPriceRange([0, Number(e.target.value)])}
                  className="w-full accent-[#8C2F2F]"
                />
              </div>

              {/* Chef */}
              <div className="mb-6">
                <h4 className="text-xs font-medium text-foreground mb-3">Đầu bếp phụ trách</h4>
                <div className="flex flex-col gap-2">
                  {chefs.map((chef) => (
                    <button
                      key={chef}
                      onClick={() => setSelectedChef(chef)}
                      className={`text-sm text-left px-3 py-1.5 transition-colors ${
                        selectedChef === chef
                          ? "bg-[#8C2F2F] text-[#F7F3EC]"
                          : "text-muted-foreground hover:text-foreground hover:bg-muted"
                      }`}
                    >
                      {chef}
                    </button>
                  ))}
                </div>
              </div>

              {/* Pieces */}
              <div>
                <h4 className="text-xs font-medium text-foreground mb-3">Số món trong set</h4>
                {[["1–5 món", [1,5]], ["6–10 món", [6,10]], ["11–15 món", [11,15]], ["15+ món", [15,99]]].map(([label]) => (
                  <label key={label as string} className="flex items-center gap-2 py-1 cursor-pointer">
                    <input type="checkbox" className="accent-[#8C2F2F]" />
                    <span className="text-sm text-muted-foreground">{label as string}</span>
                  </label>
                ))}
              </div>
            </div>
          </aside>

          {/* Main */}
          <div className="flex-1">
            {/* Sort bar */}
            <div className="flex items-center justify-between mb-6 gap-4 flex-wrap">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setShowFilter(!showFilter)}
                  className="md:hidden flex items-center gap-2 text-sm border border-border px-3 py-2 hover:bg-muted transition-colors"
                >
                  <SlidersHorizontal size={14} /> Bộ lọc
                </button>
                <p className="text-sm text-muted-foreground">
                  <span className="text-foreground font-medium">{filtered.length}</span> kết quả
                </p>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs text-muted-foreground">Sắp xếp:</span>
                <div className="relative">
                  <select
                    value={sort}
                    onChange={(e) => setSort(e.target.value)}
                    className="appearance-none border border-border bg-background px-4 py-2 pr-8 text-sm outline-none focus:border-[#8C2F2F] cursor-pointer"
                  >
                    {sorts.map((s) => <option key={s}>{s}</option>)}
                  </select>
                  <ChevronDown size={14} className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
                </div>
              </div>
            </div>

            {/* Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {displayed.map((item) => (
                <div key={item.id} className="group bg-card border border-border overflow-hidden hover:border-[#8C2F2F]/40 transition-colors">
                  <div className="relative overflow-hidden aspect-[4/3] bg-muted">
                    <img
                      src={item.img}
                      alt={item.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                    />
                    <div className="absolute top-3 left-3">
                      <span className="bg-[#1A1A1A]/80 text-[#D8CFC0] text-[10px] tracking-wide px-2 py-1">
                        {item.category}
                      </span>
                    </div>
                  </div>
                  <div className="p-5">
                    <p className="text-[10px] tracking-[0.15em] uppercase text-muted-foreground mb-1">{item.pieces} món · {item.chef}</p>
                    <h3 className="font-serif text-lg font-medium mb-2" style={{ fontFamily: "'Shippori Mincho', serif" }}>
                      {item.name}
                    </h3>
                    <div className="flex items-center gap-1 mb-4">
                      <Star size={11} className="fill-[#8C2F2F] text-[#8C2F2F]" />
                      <span className="text-xs font-medium">{item.rating}</span>
                      <span className="text-xs text-muted-foreground">({item.reviews} đánh giá)</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="font-medium">{item.price.toLocaleString("vi-VN")}₫</span>
                      <Link
                        to={`/menu/${item.id}`}
                        className="text-[10px] tracking-widest uppercase text-[#8C2F2F] border border-[#8C2F2F] px-3 py-1.5 hover:bg-[#8C2F2F] hover:text-[#F7F3EC] transition-colors"
                      >
                        Xem chi tiết
                      </Link>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex justify-center gap-2 mt-12">
                {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
                  <button
                    key={p}
                    onClick={() => setPage(p)}
                    className={`w-9 h-9 text-sm transition-colors ${
                      page === p
                        ? "bg-[#8C2F2F] text-[#F7F3EC]"
                        : "border border-border text-muted-foreground hover:border-[#8C2F2F] hover:text-foreground"
                    }`}
                  >
                    {p}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
