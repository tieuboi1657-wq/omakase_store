import { Link } from "react-router"
import { useState } from "react"
import { Eye, EyeOff } from "lucide-react"

export function Login() {
  const [showPass, setShowPass] = useState(false)

  return (
    <div className="min-h-screen bg-background flex">
      {/* Left: Restaurant image */}
      <div className="hidden md:block w-1/2 relative overflow-hidden">
        <img
          src="https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=1000&h=1400&fit=crop&auto=format"
          alt="Không gian nhà hàng Omakase"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#1A1A1A]/20 to-[#1A1A1A]/60" />
        <div className="absolute bottom-12 left-12 right-12">
          <p
            className="font-serif text-3xl text-[#F7F3EC] font-light leading-snug"
            style={{ fontFamily: "'Shippori Mincho', serif" }}
          >
            "Omakase — để đầu bếp kể câu chuyện bằng ẩm thực"
          </p>
          <div className="w-10 h-px bg-[#8C2F2F] mt-4" />
        </div>
      </div>

      {/* Right: Form */}
      <div className="flex-1 flex flex-col items-center justify-center px-8 py-12">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-3 mb-12">
          <div className="w-10 h-10 rounded-full bg-[#1A1A1A] flex items-center justify-center">
            <span className="text-[#F7F3EC] font-serif text-base">御</span>
          </div>
          <div>
            <div className="font-serif text-lg font-semibold tracking-wide" style={{ fontFamily: "'Shippori Mincho', serif" }}>OMAKASE</div>
            <div className="text-[9px] tracking-[0.2em] text-muted-foreground uppercase">Online</div>
          </div>
        </Link>

        <div className="w-full max-w-sm">
          <h2 className="font-serif text-2xl font-light mb-1" style={{ fontFamily: "'Shippori Mincho', serif" }}>
            Đăng nhập
          </h2>
          <p className="text-sm text-muted-foreground mb-8">Chào mừng trở lại</p>

          <form className="flex flex-col gap-5">
            <div>
              <label className="block text-xs tracking-wide text-foreground mb-2">Email / Tên đăng nhập</label>
              <input
                type="email"
                placeholder="your@email.com"
                className="w-full border border-border bg-white px-4 py-3 text-sm outline-none focus:border-[#8C2F2F] transition-colors placeholder:text-muted-foreground"
              />
            </div>

            <div>
              <label className="block text-xs tracking-wide text-foreground mb-2">Mật khẩu</label>
              <div className="relative">
                <input
                  type={showPass ? "text" : "password"}
                  placeholder="••••••••"
                  className="w-full border border-border bg-white px-4 py-3 pr-11 text-sm outline-none focus:border-[#8C2F2F] transition-colors placeholder:text-muted-foreground"
                />
                <button
                  type="button"
                  onClick={() => setShowPass(!showPass)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                >
                  {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" className="w-4 h-4 accent-[#8C2F2F]" />
                <span className="text-xs text-muted-foreground">Ghi nhớ đăng nhập</span>
              </label>
              <a href="#" className="text-xs text-[#8C2F2F] hover:underline">Quên mật khẩu?</a>
            </div>

            <button
              type="submit"
              className="w-full bg-[#8C2F2F] text-[#F7F3EC] py-3 text-sm tracking-widest uppercase hover:bg-[#7A2828] transition-colors"
            >
              Đăng nhập
            </button>
          </form>

          <p className="text-center text-sm text-muted-foreground mt-8">
            Chưa có tài khoản?{" "}
            <Link to="/register" className="text-[#8C2F2F] hover:underline font-medium">
              Đăng ký ngay
            </Link>
          </p>

          <div className="mt-8 pt-8 border-t border-border text-center">
            <p className="text-xs text-muted-foreground mb-4">Hoặc tiếp tục với</p>
            <div className="flex gap-3">
              <button className="flex-1 border border-border py-2.5 text-xs text-foreground hover:bg-muted transition-colors tracking-wide">
                Google
              </button>
              <button className="flex-1 border border-border py-2.5 text-xs text-foreground hover:bg-muted transition-colors tracking-wide">
                Facebook
              </button>
            </div>
          </div>
        </div>

        <Link to="/" className="mt-8 text-xs text-muted-foreground hover:text-foreground transition-colors">
          ← Về trang chủ
        </Link>
      </div>
    </div>
  )
}
