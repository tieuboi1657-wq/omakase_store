import { useState } from "react"
import { Search, X, ChevronRight } from "lucide-react"

const allOrders = [
  { id: "OMK-1024", customer: "Nguyễn Thị Mai", items: "Omakase Shun × 2", datetime: "22/09/2025 · 20:00", total: 3700000, status: "Đang xử lý" },
  { id: "OMK-1023", customer: "Trần Văn Hùng", items: "Omakase Yuki × 1", datetime: "22/09/2025 · 18:30", total: 4200000, status: "Hoàn tất" },
  { id: "OMK-1022", customer: "Lê Thu Hương", items: "Set Trưa Hana × 3", datetime: "22/09/2025 · 12:00", total: 2040000, status: "Hoàn tất" },
  { id: "OMK-1021", customer: "Phạm Minh Tuấn", items: "Nigiri Kaiseki × 2", datetime: "21/09/2025 · 19:30", total: 2900000, status: "Hoàn tất" },
  { id: "OMK-1020", customer: "Võ Thị Lan", items: "Omakase Sakura × 1", datetime: "21/09/2025 · 18:00", total: 2950000, status: "Đã hủy" },
  { id: "OMK-1019", customer: "Đặng Quốc Nam", items: "Chirashi Premium × 2", datetime: "20/09/2025 · 12:30", total: 1700000, status: "Hoàn tất" },
  { id: "OMK-1018", customer: "Hoàng Minh Hiếu", items: "Omakase Shun × 1", datetime: "20/09/2025 · 19:00", total: 1850000, status: "Đang xử lý" },
  { id: "OMK-1017", customer: "Bùi Thị Xuân", items: "Set Trưa Hana × 2", datetime: "19/09/2025 · 11:30", total: 1360000, status: "Hoàn tất" },
]

const tabs = ["Tất cả", "Đang xử lý", "Hoàn tất", "Đã hủy"]
const statusColors: Record<string, string> = {
  "Hoàn tất": "bg-green-100 text-green-700",
  "Đang xử lý": "bg-amber-100 text-amber-700",
  "Đã hủy": "bg-red-100 text-red-700",
}

export function Orders() {
  const [activeTab, setActiveTab] = useState("Tất cả")
  const [search, setSearch] = useState("")
  const [filterDate, setFilterDate] = useState("")
  const [selectedOrder, setSelectedOrder] = useState<typeof allOrders[0] | null>(null)
  const [orders, setOrders] = useState(allOrders)

  const filtered = orders.filter((o) => {
    if (activeTab !== "Tất cả" && o.status !== activeTab) return false
    if (search && !o.id.includes(search) && !o.customer.toLowerCase().includes(search.toLowerCase())) return false
    return true
  })

  const updateStatus = (id: string, newStatus: string) => {
    setOrders((prev) => prev.map((o) => o.id === id ? { ...o, status: newStatus } : o))
    if (selectedOrder?.id === id) setSelectedOrder((o) => o ? { ...o, status: newStatus } : o)
  }

  return (
    <div className="p-8 min-h-screen bg-[#F0EDE6] flex flex-col">
      <div className="mb-8">
        <p className="text-xs tracking-[0.2em] uppercase text-[#8C2F2F] mb-1">Quản lý</p>
        <h1 className="font-serif text-3xl font-light" style={{ fontFamily: "'Shippori Mincho', serif" }}>
          Đơn hàng & Đặt chỗ
        </h1>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-border mb-6 bg-card">
        {tabs.map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-5 py-3 text-sm tracking-wide transition-colors ${
              activeTab === tab
                ? "border-b-2 border-[#8C2F2F] text-[#8C2F2F] -mb-px"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            {tab}
            <span className="ml-2 text-xs text-muted-foreground">
              ({orders.filter((o) => tab === "Tất cả" || o.status === tab).length})
            </span>
          </button>
        ))}
      </div>

      {/* Filters */}
      <div className="bg-card border border-border p-4 mb-6 flex items-center gap-4 flex-wrap">
        <div className="flex items-center gap-2 border border-border bg-background px-3 py-2 flex-1 max-w-xs">
          <Search size={14} className="text-muted-foreground" />
          <input
            type="text"
            placeholder="Tìm mã đơn, khách hàng..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="flex-1 text-sm bg-transparent outline-none placeholder:text-muted-foreground"
          />
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground">Ngày:</span>
          <input
            type="date"
            value={filterDate}
            onChange={(e) => setFilterDate(e.target.value)}
            className="border border-border bg-background px-3 py-2 text-sm outline-none focus:border-[#8C2F2F]"
          />
        </div>
      </div>

      {/* Content */}
      <div className={`flex gap-6 ${selectedOrder ? "flex-col xl:flex-row" : ""}`}>
        {/* Table */}
        <div className="flex-1 bg-card border border-border overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border bg-[#F7F3EC]">
                {["Mã đơn", "Khách hàng", "Set đã đặt", "Ngày-giờ", "Tổng tiền", "Trạng thái", ""].map((h) => (
                  <th key={h} className="px-4 py-3 text-left text-xs tracking-wide text-muted-foreground font-normal">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((order, i) => (
                <tr
                  key={order.id}
                  onClick={() => setSelectedOrder(order)}
                  className={`${i < filtered.length - 1 ? "border-b border-border" : ""} cursor-pointer transition-colors ${
                    selectedOrder?.id === order.id ? "bg-[#F7F3EC]" : "hover:bg-muted/30"
                  }`}
                >
                  <td className="px-4 py-3 font-mono text-xs text-muted-foreground">{order.id}</td>
                  <td className="px-4 py-3 text-sm">{order.customer}</td>
                  <td className="px-4 py-3 text-sm text-muted-foreground">{order.items}</td>
                  <td className="px-4 py-3 text-xs text-muted-foreground">{order.datetime}</td>
                  <td className="px-4 py-3 text-sm font-medium">{order.total.toLocaleString("vi-VN")}₫</td>
                  <td className="px-4 py-3">
                    <span className={`text-[10px] font-medium px-2 py-1 rounded-full ${statusColors[order.status]}`}>
                      {order.status}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <ChevronRight size={14} className="text-muted-foreground" />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Slide panel */}
        {selectedOrder && (
          <div className="w-full xl:w-80 bg-card border border-border shrink-0">
            <div className="flex items-center justify-between px-5 py-4 border-b border-border">
              <div>
                <p className="font-mono text-xs text-muted-foreground">{selectedOrder.id}</p>
                <p className="text-sm font-medium mt-0.5">{selectedOrder.customer}</p>
              </div>
              <button onClick={() => setSelectedOrder(null)} className="text-muted-foreground hover:text-foreground">
                <X size={16} />
              </button>
            </div>

            <div className="p-5 flex flex-col gap-5">
              <div>
                <p className="text-[10px] tracking-[0.2em] uppercase text-muted-foreground mb-2">Chi tiết đặt chỗ</p>
                <div className="bg-muted p-3 text-sm flex flex-col gap-1">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Ngày-giờ</span>
                    <span>{selectedOrder.datetime}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Set đặt</span>
                    <span className="text-right max-w-[160px]">{selectedOrder.items}</span>
                  </div>
                  <div className="flex justify-between font-medium">
                    <span>Tổng tiền</span>
                    <span>{selectedOrder.total.toLocaleString("vi-VN")}₫</span>
                  </div>
                </div>
              </div>

              <div>
                <p className="text-[10px] tracking-[0.2em] uppercase text-muted-foreground mb-2">Trạng thái hiện tại</p>
                <span className={`text-[10px] font-medium px-2.5 py-1.5 rounded-full ${statusColors[selectedOrder.status]}`}>
                  {selectedOrder.status}
                </span>
              </div>

              <div>
                <p className="text-[10px] tracking-[0.2em] uppercase text-muted-foreground mb-2">Cập nhật trạng thái</p>
                <div className="flex flex-col gap-2">
                  {["Đang xử lý", "Hoàn tất", "Đã hủy"].map((s) => (
                    <button
                      key={s}
                      onClick={() => updateStatus(selectedOrder.id, s)}
                      className={`px-3 py-2 text-xs text-left border transition-colors ${
                        selectedOrder.status === s
                          ? "border-[#8C2F2F] text-[#8C2F2F] bg-[#8C2F2F]/5"
                          : "border-border text-muted-foreground hover:border-foreground hover:text-foreground"
                      }`}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
