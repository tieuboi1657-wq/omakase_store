import { useState } from "react"
import { TrendingUp, ShoppingBag, Users, Award } from "lucide-react"
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend, BarChart, Bar,
} from "recharts"

const weeklyData = [
  { label: "T2", revenue: 38, orders: 42 },
  { label: "T3", revenue: 45, orders: 51 },
  { label: "T4", revenue: 32, orders: 38 },
  { label: "T5", revenue: 52, orders: 60 },
  { label: "T6", revenue: 61, orders: 72 },
  { label: "T7", revenue: 74, orders: 85 },
  { label: "CN", revenue: 68, orders: 78 },
]

const monthlyData = [
  { label: "T4", revenue: 185, orders: 210 },
  { label: "T5", revenue: 210, orders: 245 },
  { label: "T6", revenue: 195, orders: 228 },
  { label: "T7", revenue: 240, orders: 278 },
  { label: "T8", revenue: 268, orders: 305 },
  { label: "T9", revenue: 284, orders: 322 },
]

const categoryData = [
  { name: "Full-course", value: 42 },
  { name: "Nigiri", value: 28 },
  { name: "Sashimi", value: 18 },
  { name: "Chirashi", value: 12 },
]

const PIE_COLORS = ["#8C2F2F", "#4A3324", "#B85C38", "#D8CFC0"]

const topSets = [
  { rank: 1, name: "Omakase Shun", category: "Nigiri", sold: 284, revenue: 525400000 },
  { rank: 2, name: "Omakase Yuki", category: "Full-course", sold: 198, revenue: 831600000 },
  { rank: 3, name: "Set Trưa Hana", category: "Sashimi", sold: 412, revenue: 280160000 },
  { rank: 4, name: "Omakase Sakura", category: "Full-course", sold: 167, revenue: 492650000 },
  { rank: 5, name: "Chirashi Premium", category: "Chirashi", sold: 143, revenue: 121550000 },
]

const periods = ["Tuần", "Tháng", "Quý"]

export function Reports() {
  const [period, setPeriod] = useState("Tháng")
  const chartData = period === "Tuần" ? weeklyData : monthlyData

  const totalRevenue = chartData.reduce((s, d) => s + d.revenue, 0)
  const totalOrders = chartData.reduce((s, d) => s + d.orders, 0)

  return (
    <div className="p-8 min-h-screen bg-[#F0EDE6]">
      {/* Header */}
      <div className="mb-8 flex items-end justify-between flex-wrap gap-4">
        <div>
          <p className="text-xs tracking-[0.2em] uppercase text-[#8C2F2F] mb-1">Thống kê</p>
          <h1 className="font-serif text-3xl font-light" style={{ fontFamily: "'Shippori Mincho', serif" }}>
            Báo cáo doanh thu
          </h1>
        </div>
        <div className="flex gap-1 border border-border bg-card">
          {periods.map((p) => (
            <button
              key={p}
              onClick={() => setPeriod(p)}
              className={`px-4 py-2 text-sm transition-colors ${
                period === p ? "bg-[#8C2F2F] text-[#F7F3EC]" : "text-muted-foreground hover:bg-muted"
              }`}
            >
              {p}
            </button>
          ))}
          <button className="px-4 py-2 text-sm text-muted-foreground hover:bg-muted border-l border-border flex items-center gap-1">
            Tùy chọn
          </button>
        </div>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {[
          { label: "Doanh thu", value: `${totalRevenue}tr`, unit: "VND", icon: TrendingUp, delta: "+18%" },
          { label: "Số đơn hàng", value: totalOrders, unit: "đơn", icon: ShoppingBag, delta: "+12%" },
          { label: "Khách hàng mới", value: "86", unit: "người", icon: Users, delta: "+7%" },
          { label: "Set bán chạy", value: "Omakase Shun", unit: "284 suất", icon: Award, delta: "#1" },
        ].map((stat) => (
          <div key={stat.label} className="bg-card border border-border p-5">
            <div className="flex items-start justify-between mb-4">
              <div className="w-9 h-9 rounded-sm bg-[#F7F3EC] flex items-center justify-center text-[#8C2F2F]">
                <stat.icon size={18} />
              </div>
              <span className="text-xs text-green-600 font-medium">{stat.delta}</span>
            </div>
            <p className="text-xl font-light font-serif mb-0.5" style={{ fontFamily: "'Shippori Mincho', serif" }}>
              {stat.value}
            </p>
            <p className="text-xs text-muted-foreground">{stat.label}</p>
            <p className="text-[10px] text-muted-foreground/70 mt-0.5">{stat.unit}</p>
          </div>
        ))}
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 mb-6">
        {/* Line chart */}
        <div className="xl:col-span-2 bg-card border border-border p-6">
          <h2 className="text-sm font-medium mb-6">
            Doanh thu theo {period === "Tuần" ? "tuần" : "tháng"}
            <span className="ml-2 text-xs text-muted-foreground">(triệu VND)</span>
          </h2>
          <ResponsiveContainer width="100%" height={240}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#D8CFC0" />
              <XAxis dataKey="label" tick={{ fontSize: 11, fill: "#6B5E50" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: "#6B5E50" }} axisLine={false} tickLine={false} />
              <Tooltip
                contentStyle={{ background: "#1A1A1A", border: "none", borderRadius: 0, color: "#F7F3EC", fontSize: 12 }}
                formatter={(v: number) => [`${v}tr`, "Doanh thu"]}
              />
              <Line type="monotone" dataKey="revenue" stroke="#8C2F2F" strokeWidth={2.5} dot={{ fill: "#8C2F2F", r: 4 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Pie chart */}
        <div className="bg-card border border-border p-6">
          <h2 className="text-sm font-medium mb-6">Tỷ trọng theo danh mục</h2>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie data={categoryData} cx="50%" cy="50%" outerRadius={80} dataKey="value" label={({ name, value }) => `${value}%`} labelLine={false}>
                {categoryData.map((_, index) => (
                  <Cell key={index} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                ))}
              </Pie>
              <Tooltip contentStyle={{ background: "#1A1A1A", border: "none", color: "#F7F3EC", fontSize: 12 }} />
            </PieChart>
          </ResponsiveContainer>
          <div className="flex flex-col gap-2 mt-2">
            {categoryData.map((item, i) => (
              <div key={item.name} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-sm" style={{ background: PIE_COLORS[i] }} />
                  <span className="text-muted-foreground">{item.name}</span>
                </div>
                <span className="font-medium">{item.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Orders bar chart */}
      <div className="bg-card border border-border p-6 mb-6">
        <h2 className="text-sm font-medium mb-6">Số đơn hàng</h2>
        <ResponsiveContainer width="100%" height={160}>
          <BarChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#D8CFC0" />
            <XAxis dataKey="label" tick={{ fontSize: 11, fill: "#6B5E50" }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 11, fill: "#6B5E50" }} axisLine={false} tickLine={false} />
            <Tooltip contentStyle={{ background: "#1A1A1A", border: "none", color: "#F7F3EC", fontSize: 12 }} />
            <Bar dataKey="orders" fill="#4A3324" radius={[2, 2, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Top 5 table */}
      <div className="bg-card border border-border">
        <div className="px-6 py-4 border-b border-border">
          <h2 className="text-sm font-medium">Top 5 Set bán chạy nhất</h2>
        </div>
        <table className="w-full">
          <thead>
            <tr className="border-b border-border bg-[#F7F3EC]">
              {["#", "Tên set", "Danh mục", "Số suất bán", "Doanh thu"].map((h) => (
                <th key={h} className="px-5 py-3 text-left text-xs tracking-wide text-muted-foreground font-normal">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {topSets.map((set, i) => (
              <tr key={set.rank} className={`${i < topSets.length - 1 ? "border-b border-border" : ""} hover:bg-muted/30 transition-colors`}>
                <td className="px-5 py-4">
                  <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-medium ${
                    set.rank === 1 ? "bg-[#8C2F2F] text-[#F7F3EC]" :
                    set.rank === 2 ? "bg-[#4A3324] text-[#D8CFC0]" :
                    set.rank === 3 ? "bg-[#B85C38] text-[#F7F3EC]" : "bg-muted text-muted-foreground"
                  }`}>
                    {set.rank}
                  </span>
                </td>
                <td className="px-5 py-4 text-sm font-medium">{set.name}</td>
                <td className="px-5 py-4 text-sm text-muted-foreground">{set.category}</td>
                <td className="px-5 py-4 text-sm font-medium">{set.sold.toLocaleString()} suất</td>
                <td className="px-5 py-4 text-sm font-medium text-[#8C2F2F]">
                  {(set.revenue / 1000000).toFixed(1)}tr ₫
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
