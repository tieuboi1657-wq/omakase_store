import { Link } from "react-router"
import { useState } from "react"
import { Eye, EyeOff } from "lucide-react"

export function Register() {
  const [showPass, setShowPass] = useState(false)
  const [showConfirm, setShowConfirm] = useState(false)

  return (
    <div className="min-h-screen bg-background flex">
      {/* Left: Image */}
      <div className="hidden md:block w-1/2 relative overflow-hidden">
        <img
          src="https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=1000&h=1400&fit=crop&auto=format"
          alt="Nhà hàng Omakase"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#1A1A1A]/10 to-[#1A1A1A]/70" />
        <div className="absolute bottom-12 left-12 right-12">
          <p className="font-serif text-3xl text-[#F7F3EC] font-light leading-snug" style={{ fontFamily: "'Shippori Mincho', serif" }}>
            Gia nhập cộng đồng yêu Omakase
          </p>
          <p className="text-[#D8CFC0] text-sm mt-3 leading-relaxed">
            Nhận thông báo ưu đãi sớm nhất và trải nghiệm ẩm thực độc quyền.
          </p>
          <div className="w-10 h-px bg-[#8C2F2F] mt-4" />
        </div>
      </div>

      {/* Right: Form */}
      <div className="flex-1 flex flex-col items-center justify-center px-8 py-12">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-3 mb-10">
          <div className="w-10 h-10 rounded-full bg-[#1A1A1A] flex items-center justify-center">
            <span className="text-[#F7F3EC] font-serif text-base">御</span>
          </div>
          <div>
            <div className="font-serif text-lg font-semibold tracking-wide" style={{ fontFamily: "'Shippori Mincho', serif" }}>OMAKASE</div>
            <div className="text-[9px] tracking-[0.2em] text-muted-foreground uppercase">Online</div>
          </div>
        </Link>

        <div className="w-full max-w-sm">
          <h2 className="font-serif text-2xl font-light mb-1" style={{ fontFamily: "'Shippori Mincho', serif" }}>
            Tạo tài khoản
          </h2>
          <p className="text-sm text-muted-foreground mb-8">Tham gia cùng hàng nghìn thực khách</p>

          <form className="flex flex-col gap-4">
            <div>
              <label className="block text-xs tracking-wide text-foreground mb-2">Họ và tên</label>
              <input
                type="text"
                placeholder="Nguyễn Văn An"
                className="w-full border border-border bg-white px-4 py-3 text-sm outline-none focus:border-[#8C2F2F] transition-colors placeholder:text-muted-foreground"
              />
            </div>

            <div>
              <label className="block text-xs tracking-wide text-foreground mb-2">Email</label>
              <input
                type="email"
                placeholder="your@email.com"
                className="w-full border border-border bg-white px-4 py-3 text-sm outline-none focus:border-[#8C2F2F] transition-colors placeholder:text-muted-foreground"
              />
            </div>

            <div>
              <label className="block text-xs tracking-wide text-foreground mb-2">Số điện thoại</label>
              <input
                type="tel"
                placeholder="0901 234 567"
                className="w-full border border-border bg-white px-4 py-3 text-sm outline-none focus:border-[#8C2F2F] transition-colors placeholder:text-muted-foreground"
              />
            </div>

            <div>
              <label className="block text-xs tracking-wide text-foreground mb-2">Mật khẩu</label>
              <div className="relative">
                <input
                  type={showPass ? "text" : "password"}
                  placeholder="Tối thiểu 8 ký tự"
                  className="w-full border border-border bg-white px-4 py-3 pr-11 text-sm outline-none focus:border-[#8C2F2F] transition-colors placeholder:text-muted-foreground"
                />
                <button type="button" onClick={() => setShowPass(!showPass)} className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                  {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs tracking-wide text-foreground mb-2">Xác nhận mật khẩu</label>
              <div className="relative">
                <input
                  type={showConfirm ? "text" : "password"}
                  placeholder="Nhập lại mật khẩu"
                  className="w-full border border-border bg-white px-4 py-3 pr-11 text-sm outline-none focus:border-[#8C2F2F] transition-colors placeholder:text-muted-foreground"
                />
                <button type="button" onClick={() => setShowConfirm(!showConfirm)} className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                  {showConfirm ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            <label className="flex items-start gap-2 cursor-pointer mt-1">
              <input type="checkbox" className="w-4 h-4 mt-0.5 accent-[#8C2F2F] shrink-0" />
              <span className="text-xs text-muted-foreground leading-relaxed">
                Tôi đồng ý với{" "}
                <a href="#" className="text-[#8C2F2F] hover:underline">Điều khoản dịch vụ</a>
                {" "}và{" "}
                <a href="#" className="text-[#8C2F2F] hover:underline">Chính sách bảo mật</a>
              </span>
            </label>

            <button
              type="submit"
              className="w-full bg-[#8C2F2F] text-[#F7F3EC] py-3 text-sm tracking-widest uppercase hover:bg-[#7A2828] transition-colors mt-2"
            >
              Đăng ký
            </button>
          </form>

          <p className="text-center text-sm text-muted-foreground mt-6">
            Đã có tài khoản?{" "}
            <Link to="/login" className="text-[#8C2F2F] hover:underline font-medium">
              Đăng nhập
            </Link>
          </p>
        </div>

        <Link to="/" className="mt-8 text-xs text-muted-foreground hover:text-foreground transition-colors">
          ← Về trang chủ
        </Link>
      </div>
    </div>
  )
}
