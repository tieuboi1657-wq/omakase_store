import { Link } from "react-router"
import { useState } from "react"
import { Search as SearchIcon, Star, SlidersHorizontal } from "lucide-react"

const allResults = [
  { id: "1", name: "Omakase Shun", category: "Nigiri", price: 1850000, rating: 4.9, reviews: 128, img: "https://images.unsplash.com/photo-1617196034183-421b4040ed20?w=500&h=350&fit=crop&auto=format", branch: "Lê Thánh Tôn" },
  { id: "2", name: "Omakase Sakura", category: "Full-course", price: 2950000, rating: 5.0, reviews: 84, img: "https://images.unsplash.com/photo-1611143669185-af224c5e3252?w=500&h=350&fit=crop&auto=format", branch: "Nguyễn Huệ" },
  { id: "3", name: "Set Trưa Hana", category: "Sashimi", price: 680000, rating: 4.8, reviews: 203, img: "https://images.unsplash.com/photo-1559410545-0bdcd187e0a6?w=500&h=350&fit=crop&auto=format", branch: "Lê Thánh Tôn" },
  { id: "4", name: "Omakase Yuki", category: "Full-course", price: 4200000, rating: 5.0, reviews: 56, img: "https://images.unsplash.com/photo-1553621042-f6e147245754?w=500&h=350&fit=crop&auto=format", branch: "Hà Nội" },
  { id: "5", name: "Chirashi Premium", category: "Chirashi", price: 850000, rating: 4.7, reviews: 172, img: "https://images.unsplash.com/photo-1569050467447-ce54b3bbc37d?w=500&h=350&fit=crop&auto=format", branch: "Nguyễn Huệ" },
  { id: "6", name: "Nigiri Kaiseki", category: "Nigiri", price: 1450000, rating: 4.9, reviews: 93, img: "https://images.unsplash.com/photo-1617196034199-ce0d0fd6e34a?w=500&h=350&fit=crop&auto=format", branch: "Lê Thánh Tôn" },
]

const categories = ["Tất cả", "Nigiri", "Sashimi", "Chirashi", "Full-course"]
const branches = ["Tất cả chi nhánh", "Lê Thánh Tôn", "Nguyễn Huệ", "Hà Nội"]

export function Search() {
  const [query, setQuery] = useState("")
  const [searched, setSearched] = useState(false)
  const [selectedCat, setSelectedCat] = useState("Tất cả")
  const [selectedBranch, setSelectedBranch] = useState("Tất cả chi nhánh")
  const [minRating, setMinRating] = useState(0)

  const handleSearch = () => setSearched(true)

  const results = searched
    ? allResults.filter((r) => {
        if (query && !r.name.toLowerCase().includes(query.toLowerCase()) && !r.category.toLowerCase().includes(query.toLowerCase())) return false
        if (selectedCat !== "Tất cả" && r.category !== selectedCat) return false
        if (selectedBranch !== "Tất cả chi nhánh" && r.branch !== selectedBranch) return false
        if (r.rating < minRating) return false
        return true
      })
    : []

  return (
    <div className="min-h-screen bg-background">
      {/* Search header */}
      <div className="bg-[#EDE9E0] border-b border-border py-12">
        <div className="max-w-3xl mx-auto px-6">
          <p className="text-xs tracking-[0.3em] uppercase text-[#8C2F2F] mb-4 text-center">Tìm kiếm</p>
          <h1
            className="font-serif text-3xl font-light text-center mb-8"
            style={{ fontFamily: "'Shippori Mincho', serif" }}
          >
            Tìm set Omakase
          </h1>
          <div className="flex gap-0 border border-border bg-background">
            <SearchIcon size={18} className="ml-5 self-center text-muted-foreground shrink-0" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSearch()}
              placeholder="Tìm set Omakase, món ăn, chi nhánh..."
              className="flex-1 px-4 py-4 text-sm bg-transparent outline-none placeholder:text-muted-foreground"
            />
            <button
              onClick={handleSearch}
              className="bg-[#8C2F2F] text-[#F7F3EC] px-8 py-4 text-sm tracking-widest uppercase hover:bg-[#7A2828] transition-colors shrink-0"
            >
              Tìm kiếm
            </button>
          </div>
        </div>
      </div>

      {/* Results */}
      <div className="max-w-7xl mx-auto px-6 py-10">
        <div className="flex gap-10">
          {/* Sidebar */}
          <aside className="hidden md:block w-56 shrink-0">
            <div className="sticky top-20">
              <div className="flex items-center gap-2 mb-5">
                <SlidersHorizontal size={14} className="text-[#8C2F2F]" />
                <h3 className="text-xs tracking-[0.2em] uppercase text-[#8C2F2F]">Bộ lọc</h3>
              </div>

              {/* Category */}
              <div className="mb-6">
                <h4 className="text-xs font-medium text-foreground mb-3">Danh mục</h4>
                <div className="flex flex-col gap-1">
                  {categories.map((cat) => (
                    <button
                      key={cat}
                      onClick={() => setSelectedCat(cat)}
                      className={`text-sm text-left px-3 py-1.5 transition-colors ${
                        selectedCat === cat ? "bg-[#8C2F2F] text-[#F7F3EC]" : "text-muted-foreground hover:text-foreground hover:bg-muted"
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              {/* Price range */}
              <div className="mb-6">
                <h4 className="text-xs font-medium text-foreground mb-3">Khoảng giá</h4>
                <input type="range" min={0} max={5000000} step={100000} className="w-full accent-[#8C2F2F]" />
                <div className="flex justify-between text-xs text-muted-foreground mt-1">
                  <span>0₫</span><span>5.000.000₫</span>
                </div>
              </div>

              {/* Branch */}
              <div className="mb-6">
                <h4 className="text-xs font-medium text-foreground mb-3">Chi nhánh</h4>
                <div className="flex flex-col gap-1">
                  {branches.map((b) => (
                    <button
                      key={b}
                      onClick={() => setSelectedBranch(b)}
                      className={`text-sm text-left px-3 py-1.5 transition-colors ${
                        selectedBranch === b ? "bg-[#8C2F2F] text-[#F7F3EC]" : "text-muted-foreground hover:text-foreground hover:bg-muted"
                      }`}
                    >
                      {b}
                    </button>
                  ))}
                </div>
              </div>

              {/* Rating */}
              <div>
                <h4 className="text-xs font-medium text-foreground mb-3">Đánh giá tối thiểu</h4>
                {[4, 4.5, 4.8, 5].map((r) => (
                  <label key={r} className="flex items-center gap-2 py-1 cursor-pointer">
                    <input
                      type="radio"
                      name="rating"
                      className="accent-[#8C2F2F]"
                      onChange={() => setMinRating(r)}
                    />
                    <div className="flex items-center gap-1">
                      <Star size={11} className="fill-[#8C2F2F] text-[#8C2F2F]" />
                      <span className="text-sm text-muted-foreground">{r}+</span>
                    </div>
                  </label>
                ))}
              </div>
            </div>
          </aside>

          {/* Results grid */}
          <div className="flex-1">
            {searched ? (
              <>
                <p className="text-sm text-muted-foreground mb-6">
                  Tìm thấy <span className="text-foreground font-medium">{results.length}</span> kết quả
                  {query && <> cho "<span className="text-foreground">{query}</span>"</>}
                </p>

                {results.length === 0 ? (
                  <div className="text-center py-20">
                    <SearchIcon size={40} className="mx-auto text-border mb-4" />
                    <p className="text-muted-foreground">Không tìm thấy kết quả phù hợp</p>
                    <button onClick={() => { setQuery(""); setSearched(false); }} className="mt-4 text-sm text-[#8C2F2F] hover:underline">
                      Xóa bộ lọc
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    {results.map((item) => (
                      <div key={item.id} className="group bg-card border border-border overflow-hidden hover:border-[#8C2F2F]/40 transition-colors">
                        <div className="relative overflow-hidden aspect-[4/3] bg-muted">
                          <img src={item.img} alt={item.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                        </div>
                        <div className="p-5">
                          <p className="text-[10px] tracking-[0.15em] uppercase text-muted-foreground mb-1">{item.category} · {item.branch}</p>
                          <h3 className="font-serif text-lg font-medium mb-2" style={{ fontFamily: "'Shippori Mincho', serif" }}>{item.name}</h3>
                          <div className="flex items-center gap-1 mb-4">
                            <Star size={11} className="fill-[#8C2F2F] text-[#8C2F2F]" />
                            <span className="text-xs font-medium">{item.rating}</span>
                            <span className="text-xs text-muted-foreground">({item.reviews})</span>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="font-medium">{item.price.toLocaleString("vi-VN")}₫</span>
                            <Link to={`/menu/${item.id}`} className="text-[10px] tracking-widest uppercase text-[#8C2F2F] border border-[#8C2F2F] px-3 py-1.5 hover:bg-[#8C2F2F] hover:text-[#F7F3EC] transition-colors">
                              Xem chi tiết
                            </Link>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </>
            ) : (
              <div className="text-center py-24">
                <p className="text-muted-foreground text-sm">Nhập từ khóa và nhấn tìm kiếm để xem kết quả</p>
                <div className="mt-8 flex flex-wrap gap-3 justify-center">
                  {["Omakase", "Sashimi", "Set trưa", "Premium"].map((tag) => (
                    <button
                      key={tag}
                      onClick={() => { setQuery(tag); setSearched(true) }}
                      className="text-xs border border-border px-4 py-2 text-muted-foreground hover:border-[#8C2F2F] hover:text-[#8C2F2F] transition-colors"
                    >
                      {tag}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
