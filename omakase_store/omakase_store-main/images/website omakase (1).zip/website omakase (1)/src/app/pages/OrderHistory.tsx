import { Link } from "react-router"
import { User, Package, History, Heart, Lock, LogOut } from "lucide-react"
import { useState } from "react"

const orders = [
  {
    id: "OMK-2025-0892",
    items: "Omakase Shun × 2, Set Trưa Hana × 1",
    date: "15/09/2025 · 19:00",
    total: 4380000,
    status: "Hoàn tất",
  },
  {
    id: "OMK-2025-0741",
    items: "Omakase Yuki × 1",
    date: "28/08/2025 · 18:30",
    total: 4200000,
    status: "Hoàn tất",
  },
  {
    id: "OMK-2025-0683",
    items: "Chirashi Premium × 2",
    date: "12/08/2025 · 12:00",
    total: 1700000,
    status: "Hoàn tất",
  },
  {
    id: "OMK-2025-0512",
    items: "Omakase Sakura × 1",
    date: "05/07/2025 · 19:30",
    total: 2950000,
    status: "Đã hủy",
  },
  {
    id: "OMK-2025-1024",
    items: "Omakase Shun × 1, Nigiri Kaiseki × 1",
    date: "22/09/2025 · 20:00",
    total: 3300000,
    status: "Đang xử lý",
  },
]

const statusColors: Record<string, string> = {
  "Hoàn tất": "bg-green-100 text-green-700",
  "Đang xử lý": "bg-amber-100 text-amber-700",
  "Đã hủy": "bg-red-100 text-red-700",
}

const paymentMethods = ["Chuyển khoản / Banking", "Ví điện tử (MoMo, ZaloPay)", "COD (Thanh toán tại quầy)"]

const sidebarLinks = [
  { label: "Thông tin cá nhân", to: "/profile", icon: User },
  { label: "Đơn hàng", to: "/profile/orders", icon: Package },
  { label: "Lịch sử đặt chỗ", to: "/profile/orders", icon: History },
  { label: "Món yêu thích", to: "/profile", icon: Heart },
  { label: "Đổi mật khẩu", to: "/profile", icon: Lock },
  { label: "Đăng xuất", to: "/login", icon: LogOut },
]

export function OrderHistory() {
  const [selectedPayment, setSelectedPayment] = useState(paymentMethods[0])
  const [selectedOrder, setSelectedOrder] = useState(orders[0])

  return (
    <div className="min-h-screen bg-background">
      <div className="border-b border-border">
        <div className="max-w-7xl mx-auto px-6 py-3">
          <p className="text-xs text-muted-foreground">
            <Link to="/" className="hover:text-foreground">Trang chủ</Link>
            <span className="mx-2">/</span>
            <Link to="/profile" className="hover:text-foreground">Hồ sơ</Link>
            <span className="mx-2">/</span>
            <span className="text-foreground">Lịch sử đặt chỗ</span>
          </p>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-[240px_1fr] gap-10">
          {/* Sidebar */}
          <aside>
            <div className="bg-[#1A1A1A] p-6 text-center mb-1">
              <div className="w-16 h-16 rounded-full bg-[#4A3324] text-[#D8CFC0] flex items-center justify-center text-2xl font-serif mx-auto mb-3">N</div>
              <p className="text-[#F7F3EC] font-medium text-sm">Nguyễn Thị Mai</p>
              <p className="text-[#6B6B6B] text-xs mt-0.5">mai.nguyen@email.com</p>
            </div>
            <nav className="bg-[#1A1A1A]">
              {sidebarLinks.map(({ label, to, icon: Icon }, i) => {
                const isActive = i === 1 || i === 2
                const isDanger = label === "Đăng xuất"
                return (
                  <Link
                    key={label}
                    to={to}
                    className={`flex items-center gap-3 px-5 py-3.5 text-sm transition-colors border-b border-[#2A2A2A] last:border-0 ${
                      isActive
                        ? "bg-[#8C2F2F] text-[#F7F3EC]"
                        : isDanger
                        ? "text-[#6B6B6B] hover:bg-[#2A2A2A] hover:text-red-400"
                        : "text-[#6B6B6B] hover:bg-[#2A2A2A] hover:text-[#D8CFC0]"
                    }`}
                  >
                    <Icon size={15} className="shrink-0" />
                    {label}
                  </Link>
                )
              })}
            </nav>
          </aside>

          {/* Content */}
          <div>
            <h1 className="font-serif text-2xl font-light mb-1" style={{ fontFamily: "'Shippori Mincho', serif" }}>
              Lịch sử đơn hàng
            </h1>
            <p className="text-sm text-muted-foreground mb-8">Tổng cộng {orders.length} đơn hàng</p>

            {/* Orders table */}
            <div className="border border-border mb-10">
              <div className="hidden md:grid grid-cols-[auto_2fr_1fr_1fr_1fr] gap-4 px-5 py-3 bg-muted text-xs tracking-wide text-muted-foreground border-b border-border">
                <span>Mã đơn</span>
                <span>Set / Món</span>
                <span>Ngày-giờ</span>
                <span className="text-right">Tổng tiền</span>
                <span className="text-center">Trạng thái</span>
              </div>
              {orders.map((order, i) => (
                <button
                  key={order.id}
                  onClick={() => setSelectedOrder(order)}
                  className={`w-full grid grid-cols-1 md:grid-cols-[auto_2fr_1fr_1fr_1fr] gap-2 md:gap-4 items-center px-5 py-4 text-left transition-colors ${
                    i < orders.length - 1 ? "border-b border-border" : ""
                  } ${selectedOrder.id === order.id ? "bg-[#F7F3EC]" : "hover:bg-muted/50"}`}
                >
                  <span className="font-mono text-xs text-muted-foreground">{order.id}</span>
                  <span className="text-sm">{order.items}</span>
                  <span className="text-xs text-muted-foreground">{order.date}</span>
                  <span className="text-sm font-medium md:text-right">{order.total.toLocaleString("vi-VN")}₫</span>
                  <span className="flex md:justify-center">
                    <span className={`text-[10px] font-medium px-2 py-1 rounded-full ${statusColors[order.status]}`}>
                      {order.status}
                    </span>
                  </span>
                </button>
              ))}
            </div>

            {/* Selected order detail */}
            {selectedOrder && (
              <div className="border border-border p-6 mb-8">
                <h3 className="text-sm font-medium mb-1">Thông tin đơn: {selectedOrder.id}</h3>
                <p className="text-xs text-muted-foreground mb-6">{selectedOrder.date}</p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                  <div>
                    <p className="text-xs tracking-wide text-muted-foreground mb-2">Khách hàng</p>
                    <p className="text-sm">Nguyễn Thị Mai</p>
                    <p className="text-sm text-muted-foreground">45 Nguyễn Trãi, Q.1, TP.HCM</p>
                    <p className="text-sm text-muted-foreground">0901 234 567</p>
                  </div>
                  <div>
                    <p className="text-xs tracking-wide text-muted-foreground mb-2">Set đã đặt</p>
                    <p className="text-sm">{selectedOrder.items}</p>
                    <p className="text-sm font-medium mt-2">{selectedOrder.total.toLocaleString("vi-VN")}₫</p>
                  </div>
                </div>
              </div>
            )}

            {/* Payment method */}
            <div className="border border-border p-6">
              <h3 className="text-sm font-medium mb-4">Phương thức thanh toán</h3>
              <div className="flex flex-col gap-3 mb-6">
                {paymentMethods.map((method) => (
                  <label key={method} className="flex items-center gap-3 cursor-pointer">
                    <input
                      type="radio"
                      name="payment"
                      value={method}
                      checked={selectedPayment === method}
                      onChange={() => setSelectedPayment(method)}
                      className="accent-[#8C2F2F]"
                    />
                    <span className="text-sm">{method}</span>
                  </label>
                ))}
              </div>
              <button className="bg-[#8C2F2F] text-[#F7F3EC] px-8 py-3 text-sm tracking-widest uppercase hover:bg-[#7A2828] transition-colors">
                Xác nhận thanh toán
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
