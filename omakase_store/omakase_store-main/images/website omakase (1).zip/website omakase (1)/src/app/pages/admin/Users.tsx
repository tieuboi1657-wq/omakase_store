import { useState } from "react"
import { Search, Plus, Pencil, Trash2, Ban, ChevronDown } from "lucide-react"

const initialUsers = [
  { id: "1", name: "Nguyễn Thị Mai", email: "mai.nguyen@email.com", phone: "0901 234 567", role: "Khách hàng", status: "Hoạt động", joined: "12/01/2024", avatar: "M" },
  { id: "2", name: "Trần Văn Hùng", email: "hung.tran@email.com", phone: "0902 345 678", role: "Khách hàng", status: "Hoạt động", joined: "25/02/2024", avatar: "H" },
  { id: "3", name: "Lê Thu Hương", email: "huong.le@email.com", phone: "0903 456 789", role: "Khách hàng", status: "Khóa", joined: "08/03/2024", avatar: "H" },
  { id: "4", name: "Admin System", email: "admin@omakase.vn", phone: "0904 567 890", role: "Admin", status: "Hoạt động", joined: "01/01/2024", avatar: "A" },
  { id: "5", name: "Phạm Minh Tuấn", email: "tuan.pham@email.com", phone: "0905 678 901", role: "Khách hàng", status: "Hoạt động", joined: "18/04/2024", avatar: "T" },
  { id: "6", name: "Võ Thị Lan", email: "lan.vo@email.com", phone: "0906 789 012", role: "Khách hàng", status: "Hoạt động", joined: "30/05/2024", avatar: "L" },
  { id: "7", name: "Đặng Quốc Nam", email: "nam.dang@email.com", phone: "0907 890 123", role: "Khách hàng", status: "Khóa", joined: "14/06/2024", avatar: "N" },
]

export function Users() {
  const [users, setUsers] = useState(initialUsers)
  const [search, setSearch] = useState("")
  const [filterRole, setFilterRole] = useState("Tất cả")
  const [filterStatus, setFilterStatus] = useState("Tất cả")

  const filtered = users.filter((u) => {
    const q = search.toLowerCase()
    if (q && !u.name.toLowerCase().includes(q) && !u.email.toLowerCase().includes(q)) return false
    if (filterRole !== "Tất cả" && u.role !== filterRole) return false
    if (filterStatus !== "Tất cả" && u.status !== filterStatus) return false
    return true
  })

  const toggleStatus = (id: string) =>
    setUsers((prev) =>
      prev.map((u) => u.id === id ? { ...u, status: u.status === "Hoạt động" ? "Khóa" : "Hoạt động" } : u)
    )

  return (
    <div className="p-8 min-h-screen bg-[#F0EDE6]">
      <div className="mb-8 flex items-end justify-between gap-4 flex-wrap">
        <div>
          <p className="text-xs tracking-[0.2em] uppercase text-[#8C2F2F] mb-1">Quản lý</p>
          <h1 className="font-serif text-3xl font-light" style={{ fontFamily: "'Shippori Mincho', serif" }}>
            Người dùng
          </h1>
        </div>
        <button className="flex items-center gap-2 bg-[#8C2F2F] text-[#F7F3EC] px-5 py-2.5 text-sm tracking-wide hover:bg-[#7A2828] transition-colors">
          <Plus size={16} /> Thêm người dùng
        </button>
      </div>

      {/* Filters */}
      <div className="bg-card border border-border p-4 mb-6 flex items-center gap-4 flex-wrap">
        <div className="flex items-center gap-2 border border-border bg-background px-3 py-2 flex-1 max-w-xs">
          <Search size={14} className="text-muted-foreground" />
          <input
            type="text"
            placeholder="Tìm theo tên / email..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="flex-1 text-sm bg-transparent outline-none placeholder:text-muted-foreground"
          />
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground">Vai trò:</span>
          <div className="relative">
            <select
              value={filterRole}
              onChange={(e) => setFilterRole(e.target.value)}
              className="appearance-none border border-border bg-background px-3 py-2 pr-7 text-sm outline-none cursor-pointer"
            >
              {["Tất cả", "Khách hàng", "Admin"].map((r) => <option key={r}>{r}</option>)}
            </select>
            <ChevronDown size={12} className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground">Trạng thái:</span>
          <div className="relative">
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="appearance-none border border-border bg-background px-3 py-2 pr-7 text-sm outline-none cursor-pointer"
            >
              {["Tất cả", "Hoạt động", "Khóa"].map((s) => <option key={s}>{s}</option>)}
            </select>
            <ChevronDown size={12} className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="bg-card border border-border overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="border-b border-border bg-[#F7F3EC]">
              {["Avatar", "Họ tên", "Email", "SĐT", "Vai trò", "Trạng thái", "Ngày tham gia", "Hành động"].map((h) => (
                <th key={h} className="px-4 py-3 text-left text-xs tracking-wide text-muted-foreground font-normal">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map((user, i) => (
              <tr key={user.id} className={`${i < filtered.length - 1 ? "border-b border-border" : ""} hover:bg-muted/30 transition-colors`}>
                <td className="px-4 py-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                    user.role === "Admin" ? "bg-[#8C2F2F] text-[#F7F3EC]" : "bg-[#4A3324] text-[#D8CFC0]"
                  }`}>
                    {user.avatar}
                  </div>
                </td>
                <td className="px-4 py-3 text-sm font-medium">{user.name}</td>
                <td className="px-4 py-3 text-sm text-muted-foreground">{user.email}</td>
                <td className="px-4 py-3 text-sm text-muted-foreground">{user.phone}</td>
                <td className="px-4 py-3">
                  <span className={`text-[10px] font-medium px-2 py-1 rounded-full ${
                    user.role === "Admin" ? "bg-purple-100 text-purple-700" : "bg-blue-100 text-blue-700"
                  }`}>
                    {user.role}
                  </span>
                </td>
                <td className="px-4 py-3">
                  <span className={`text-[10px] font-medium px-2 py-1 rounded-full ${
                    user.status === "Hoạt động" ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
                  }`}>
                    {user.status}
                  </span>
                </td>
                <td className="px-4 py-3 text-xs text-muted-foreground">{user.joined}</td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-1">
                    <button className="p-1.5 text-muted-foreground hover:text-foreground hover:bg-muted transition-colors rounded-sm">
                      <Pencil size={13} />
                    </button>
                    <button
                      onClick={() => toggleStatus(user.id)}
                      className="p-1.5 text-muted-foreground hover:text-amber-600 hover:bg-amber-50 transition-colors rounded-sm"
                    >
                      <Ban size={13} />
                    </button>
                    <button className="p-1.5 text-muted-foreground hover:text-red-600 hover:bg-red-50 transition-colors rounded-sm">
                      <Trash2 size={13} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="px-5 py-4 border-t border-border">
          <p className="text-xs text-muted-foreground">Hiển thị {filtered.length} / {users.length} người dùng</p>
        </div>
      </div>
    </div>
  )
}
