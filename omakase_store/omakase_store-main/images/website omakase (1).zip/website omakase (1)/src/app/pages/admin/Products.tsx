import { useState } from "react"
import { Plus, Search, Pencil, Trash2, Eye, X } from "lucide-react"

const initialProducts = [
  { id: "1", name: "Omakase Shun", category: "Nigiri", price: 1850000, status: "Đang bán", img: "https://images.unsplash.com/photo-1617196034183-421b4040ed20?w=80&h=60&fit=crop&auto=format" },
  { id: "2", name: "Omakase Sakura", category: "Full-course", price: 2950000, status: "Đang bán", img: "https://images.unsplash.com/photo-1611143669185-af224c5e3252?w=80&h=60&fit=crop&auto=format" },
  { id: "3", name: "Set Trưa Hana", category: "Sashimi", price: 680000, status: "Đang bán", img: "https://images.unsplash.com/photo-1559410545-0bdcd187e0a6?w=80&h=60&fit=crop&auto=format" },
  { id: "4", name: "Omakase Yuki", category: "Full-course", price: 4200000, status: "Đang bán", img: "https://images.unsplash.com/photo-1553621042-f6e147245754?w=80&h=60&fit=crop&auto=format" },
  { id: "5", name: "Chirashi Premium", category: "Chirashi", price: 850000, status: "Ẩn", img: "https://images.unsplash.com/photo-1569050467447-ce54b3bbc37d?w=80&h=60&fit=crop&auto=format" },
  { id: "6", name: "Nigiri Kaiseki", category: "Nigiri", price: 1450000, status: "Đang bán", img: "https://images.unsplash.com/photo-1617196034199-ce0d0fd6e34a?w=80&h=60&fit=crop&auto=format" },
  { id: "7", name: "Sashimi Mori", category: "Sashimi", price: 580000, status: "Đang bán", img: "https://images.unsplash.com/photo-1580822184713-fc5400e7fe10?w=80&h=60&fit=crop&auto=format" },
]

const categories = ["Tất cả", "Nigiri", "Sashimi", "Chirashi", "Full-course"]

export function Products() {
  const [products, setProducts] = useState(initialProducts)
  const [search, setSearch] = useState("")
  const [filterCat, setFilterCat] = useState("Tất cả")
  const [showModal, setShowModal] = useState(false)
  const [editId, setEditId] = useState<string | null>(null)
  const [page, setPage] = useState(1)
  const perPage = 5

  const filtered = products.filter((p) => {
    if (search && !p.name.toLowerCase().includes(search.toLowerCase())) return false
    if (filterCat !== "Tất cả" && p.category !== filterCat) return false
    return true
  })

  const totalPages = Math.ceil(filtered.length / perPage)
  const displayed = filtered.slice((page - 1) * perPage, page * perPage)

  const deleteProduct = (id: string) => setProducts((prev) => prev.filter((p) => p.id !== id))
  const toggleStatus = (id: string) =>
    setProducts((prev) =>
      prev.map((p) => p.id === id ? { ...p, status: p.status === "Đang bán" ? "Ẩn" : "Đang bán" } : p)
    )

  return (
    <div className="p-8 min-h-screen bg-[#F0EDE6]">
      <div className="mb-8 flex items-end justify-between gap-4 flex-wrap">
        <div>
          <p className="text-xs tracking-[0.2em] uppercase text-[#8C2F2F] mb-1">Quản lý</p>
          <h1 className="font-serif text-3xl font-light" style={{ fontFamily: "'Shippori Mincho', serif" }}>
            Set Omakase
          </h1>
        </div>
        <button
          onClick={() => { setEditId(null); setShowModal(true) }}
          className="flex items-center gap-2 bg-[#8C2F2F] text-[#F7F3EC] px-5 py-2.5 text-sm tracking-wide hover:bg-[#7A2828] transition-colors"
        >
          <Plus size={16} /> Thêm mới
        </button>
      </div>

      {/* Filters */}
      <div className="bg-card border border-border p-4 mb-6 flex items-center gap-4 flex-wrap">
        <div className="flex items-center gap-2 border border-border bg-background px-3 py-2 flex-1 max-w-xs">
          <Search size={14} className="text-muted-foreground" />
          <input
            type="text"
            placeholder="Tìm theo tên set..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="flex-1 text-sm bg-transparent outline-none placeholder:text-muted-foreground"
          />
        </div>
        <div className="flex gap-2">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setFilterCat(cat)}
              className={`px-3 py-2 text-xs transition-colors ${
                filterCat === cat ? "bg-[#8C2F2F] text-[#F7F3EC]" : "border border-border text-muted-foreground hover:bg-muted"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="bg-card border border-border overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="border-b border-border bg-[#F7F3EC]">
              {["Ảnh", "Tên set", "Danh mục", "Giá", "Trạng thái", "Hành động"].map((h) => (
                <th key={h} className="px-5 py-3 text-left text-xs tracking-wide text-muted-foreground font-normal">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {displayed.map((product, i) => (
              <tr key={product.id} className={`${i < displayed.length - 1 ? "border-b border-border" : ""} hover:bg-muted/30 transition-colors`}>
                <td className="px-5 py-3">
                  <img src={product.img} alt={product.name} className="w-14 h-10 object-cover bg-muted" />
                </td>
                <td className="px-5 py-3 text-sm font-medium">{product.name}</td>
                <td className="px-5 py-3 text-sm text-muted-foreground">{product.category}</td>
                <td className="px-5 py-3 text-sm">{product.price.toLocaleString("vi-VN")}₫</td>
                <td className="px-5 py-3">
                  <button
                    onClick={() => toggleStatus(product.id)}
                    className={`text-[10px] font-medium px-2.5 py-1 rounded-full transition-colors ${
                      product.status === "Đang bán"
                        ? "bg-green-100 text-green-700 hover:bg-green-200"
                        : "bg-gray-100 text-gray-500 hover:bg-gray-200"
                    }`}
                  >
                    {product.status}
                  </button>
                </td>
                <td className="px-5 py-3">
                  <div className="flex items-center gap-2">
                    <button onClick={() => { setEditId(product.id); setShowModal(true) }} className="p-1.5 text-muted-foreground hover:text-foreground hover:bg-muted transition-colors rounded-sm">
                      <Pencil size={14} />
                    </button>
                    <button className="p-1.5 text-muted-foreground hover:text-foreground hover:bg-muted transition-colors rounded-sm">
                      <Eye size={14} />
                    </button>
                    <button onClick={() => deleteProduct(product.id)} className="p-1.5 text-muted-foreground hover:text-red-600 hover:bg-red-50 transition-colors rounded-sm">
                      <Trash2 size={14} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="px-5 py-4 border-t border-border flex items-center justify-between">
            <p className="text-xs text-muted-foreground">
              Hiển thị {(page - 1) * perPage + 1}–{Math.min(page * perPage, filtered.length)} / {filtered.length}
            </p>
            <div className="flex gap-1">
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
                <button
                  key={p}
                  onClick={() => setPage(p)}
                  className={`w-8 h-8 text-xs transition-colors ${
                    page === p ? "bg-[#8C2F2F] text-[#F7F3EC]" : "border border-border text-muted-foreground hover:bg-muted"
                  }`}
                >
                  {p}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-[#1A1A1A]/50 flex items-center justify-center z-50 p-4">
          <div className="bg-card border border-border w-full max-w-md">
            <div className="flex items-center justify-between px-6 py-4 border-b border-border">
              <h3 className="font-medium text-sm">{editId ? "Chỉnh sửa set" : "Thêm set mới"}</h3>
              <button onClick={() => setShowModal(false)} className="text-muted-foreground hover:text-foreground">
                <X size={18} />
              </button>
            </div>
            <div className="p-6 flex flex-col gap-4">
              {[["Tên set", "text", "Omakase Shun"], ["Mô tả", "text", "10 món theo mùa..."], ["Giá (₫)", "number", "1850000"]].map(([label, type, placeholder]) => (
                <div key={label as string}>
                  <label className="block text-xs tracking-wide mb-2">{label as string}</label>
                  <input
                    type={type as string}
                    defaultValue={editId ? placeholder as string : ""}
                    placeholder={placeholder as string}
                    className="w-full border border-border px-4 py-2.5 text-sm outline-none focus:border-[#8C2F2F] transition-colors"
                  />
                </div>
              ))}
              <div>
                <label className="block text-xs tracking-wide mb-2">Danh mục</label>
                <select className="w-full border border-border px-4 py-2.5 text-sm outline-none focus:border-[#8C2F2F] bg-background">
                  {["Nigiri", "Sashimi", "Chirashi", "Full-course"].map((c) => (
                    <option key={c}>{c}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs tracking-wide mb-2">Ảnh (URL)</label>
                <input type="text" placeholder="https://images.unsplash.com/..." className="w-full border border-border px-4 py-2.5 text-sm outline-none focus:border-[#8C2F2F] transition-colors" />
              </div>
            </div>
            <div className="px-6 py-4 border-t border-border flex gap-3 justify-end">
              <button onClick={() => setShowModal(false)} className="px-5 py-2 text-sm border border-border text-muted-foreground hover:bg-muted transition-colors">
                Hủy
              </button>
              <button onClick={() => setShowModal(false)} className="px-5 py-2 text-sm bg-[#8C2F2F] text-[#F7F3EC] hover:bg-[#7A2828] transition-colors">
                {editId ? "Cập nhật" : "Thêm mới"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
