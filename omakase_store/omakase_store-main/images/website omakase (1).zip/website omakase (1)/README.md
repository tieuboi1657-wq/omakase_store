
  # website omakase

  This is a code bundle for website omakase. The original project is available at https://www.figma.com/design/E44xQGPfUW8RbB6lR0RELB/website-omakase.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  